
import React from 'react';
import { BrowserConfig } from '../types/config';

interface UpdateOverlayProps {
  config: BrowserConfig;
}

const UpdateOverlay: React.FC<UpdateOverlayProps> = ({ config }) => {
  return (
    <div className="fixed inset-0 z-[1000] bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-8">
      <div className="bg-slate-900 max-w-sm w-full rounded-[40px] border border-slate-800 p-10 text-center space-y-8 shadow-2xl animate-fade-in">
         <div className="w-24 h-24 bg-indigo-600 rounded-[32px] mx-auto flex items-center justify-center text-5xl shadow-2xl shadow-indigo-600/30">
            🔄
         </div>
         <div className="space-y-3">
            <h2 className="text-3xl font-black text-white">New Version Available</h2>
            <p className="text-slate-400 text-sm leading-relaxed">A critical update is required to continue browsing safely. Please update to version {config.system.currentVersion}.</p>
         </div>
         <div className="space-y-4 pt-4">
            <button 
              onClick={() => window.open(config.system.updateUrl, '_blank')}
              className="w-full bg-white text-slate-950 py-5 rounded-2xl font-black text-lg shadow-xl hover:scale-[1.02] active:scale-95 transition-all"
            >
              Update Now
            </button>
            <p className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">Size: ~24.5 MB • Version {config.system.currentVersion}</p>
         </div>
      </div>
    </div>
  );
};

export default UpdateOverlay;
