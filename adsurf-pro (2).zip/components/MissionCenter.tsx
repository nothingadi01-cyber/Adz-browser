
import React from 'react';
import { Mission, UserStats, CurrencyCode } from '../types/config';

interface MissionCenterProps {
  userStats: UserStats;
  onClaim: (mission: Mission) => void;
  onClose: () => void;
  currency: CurrencyCode;
}

const MISSIONS: Mission[] = [
  { id: 'daily_checkin', title: 'Daily Presence', description: 'Log in today for a quick reward.', reward: 1.00, goal: 1, type: 'checkin' },
  { id: 'news_novice', title: 'News Novice', description: 'Read 3 articles.', reward: 2.50, goal: 3, type: 'articles' },
  { id: 'news_expert', title: 'News Expert', description: 'Read 15 articles for a big bonus.', reward: 12.00, goal: 15, type: 'articles' },
  { id: 'ad_supporter', title: 'Ad Supporter', description: 'Watch 3 rewarded ads.', reward: 8.00, goal: 3, type: 'ads' },
  { id: 'search_sprint', title: 'Search Sprint', description: 'Perform 5 quick searches.', reward: 3.00, goal: 5, type: 'searches' },
  { id: 'streak_warrior', title: 'Streak Warrior', description: 'Maintain a 3-day browsing streak.', reward: 20.00, goal: 3, type: 'streak' },
];

const MissionCenter: React.FC<MissionCenterProps> = ({ userStats, onClaim, onClose, currency }) => {
  const getProgress = (mission: Mission) => {
    if (mission.type === 'checkin') {
      const today = new Date().setHours(0,0,0,0);
      return userStats.lastCheckIn === today ? 1 : 0;
    }
    if (mission.type === 'articles') return userStats.articlesRead;
    if (mission.type === 'ads') return userStats.adsWatched;
    if (mission.type === 'searches') return userStats.searchesPerformed;
    if (mission.type === 'streak') return userStats.streak;
    return 0;
  };

  const isClaimed = (missionId: string) => userStats.missionProgress[missionId] === 1;

  const formatCurrency = (val: number) => {
    const sym = currency === 'INR' ? '₹' : '$';
    const rate = currency === 'INR' ? 1 : 0.012;
    return `${sym}${(val * rate).toFixed(2)}`;
  };

  return (
    <div className="absolute inset-0 z-[60] glass flex flex-col animate-slide-up">
      <header className="p-6 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-2xl shadow-lg shadow-indigo-600/30">🏆</div>
          <div>
            <h2 className="text-xl font-black text-white leading-none">Mission Hub</h2>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Tiered Challenges • Instant Payouts</p>
          </div>
        </div>
        <button onClick={onClose} className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center text-slate-400 hover:text-white transition-colors">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
      </header>

      <div className="flex-1 overflow-auto p-6 space-y-5 scrollbar-hide">
        {MISSIONS.map(mission => {
          const current = getProgress(mission);
          const percent = Math.min((current / mission.goal) * 100, 100);
          const canClaim = current >= mission.goal && !isClaimed(mission.id);
          const claimed = isClaimed(mission.id);

          return (
            <div key={mission.id} className={`p-5 rounded-[32px] border transition-all duration-300 relative overflow-hidden ${claimed ? 'bg-slate-900/40 border-slate-800 opacity-60' : 'bg-slate-900 border-white/5 shadow-xl shadow-black/20'}`}>
              {canClaim && (
                <div className="absolute top-0 right-0 px-4 py-1 bg-emerald-500 text-white text-[9px] font-black uppercase rounded-bl-xl animate-pulse">Ready</div>
              )}
              
              <div className="flex justify-between items-start mb-4">
                <div className="space-y-1">
                  <h3 className="text-sm font-black text-white">{mission.title}</h3>
                  <p className="text-[11px] text-slate-400 font-medium leading-tight max-w-[200px]">{mission.description}</p>
                </div>
                <div className="bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-xl flex items-center gap-1.5">
                  <span className="text-[11px] font-black text-amber-500">{formatCurrency(mission.reward)}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-end">
                   <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{current} / {mission.goal}</span>
                   <span className="text-[10px] font-bold text-slate-500">{Math.round(percent)}%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden border border-white/5">
                   <div className="h-full bg-gradient-to-r from-indigo-600 to-indigo-400 transition-all duration-700" style={{ width: `${percent}%` }} />
                </div>
              </div>

              <div className="mt-5">
                {claimed ? (
                  <div className="w-full bg-slate-800/50 text-slate-500 py-3 rounded-2xl text-[10px] font-black uppercase text-center flex items-center justify-center gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                    Claimed
                  </div>
                ) : (
                  <button 
                    onClick={() => canClaim && onClaim(mission)}
                    disabled={!canClaim}
                    className={`w-full py-4 rounded-2xl text-[10px] font-black uppercase transition-all ${canClaim ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 hover:scale-[1.02] active:scale-95' : 'bg-slate-800 text-slate-600 cursor-not-allowed'}`}
                  >
                    {canClaim ? 'Claim Reward' : 'Locked'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <footer className="p-8 bg-slate-900/50 border-t border-white/5">
        <div className="flex items-center gap-4 bg-indigo-600/10 p-4 rounded-2xl border border-indigo-500/20">
           <div className="text-2xl">⚡</div>
           <p className="text-[10px] text-indigo-300 font-bold uppercase leading-relaxed tracking-wider">
             Tip: Higher browsing frequency increases your daily multiplier. Check back every 24h!
           </p>
        </div>
      </footer>
    </div>
  );
};

export default MissionCenter;
