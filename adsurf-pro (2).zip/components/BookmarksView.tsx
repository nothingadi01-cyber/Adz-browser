
import React from 'react';
import { Bookmark } from '../types/config';

interface BookmarksViewProps {
  items: Bookmark[];
  onNavigate: (url: string) => void;
  onClose: () => void;
}

const BookmarksView: React.FC<BookmarksViewProps> = ({ items, onNavigate, onClose }) => {
  return (
    <div className="absolute inset-0 z-50 bg-slate-950 flex flex-col animate-fade-in">
      <header className="p-4 border-b border-slate-800 flex items-center gap-4">
        <button onClick={onClose} className="p-2 text-slate-400">
           <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
        </button>
        <h3 className="text-lg font-bold">Bookmarks</h3>
      </header>

      <div className="flex-1 overflow-auto">
        {items.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center p-8 text-center text-slate-500">
             <div className="text-4xl mb-4">⭐</div>
             <p className="font-bold">No bookmarks saved</p>
          </div>
        ) : (
          <div className="p-4 grid grid-cols-2 gap-4">
            {items.map(item => (
              <div 
                key={item.id} 
                onClick={() => { onNavigate(item.url); onClose(); }}
                className="bg-slate-900 p-4 rounded-2xl border border-slate-800 hover:border-indigo-500/50 transition-all cursor-pointer group"
              >
                 <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center text-xl mb-3 group-hover:scale-110 transition-transform">
                   {item.title[0]}
                 </div>
                 <div className="text-xs font-bold text-slate-200 truncate">{item.title}</div>
                 <div className="text-[9px] text-slate-500 truncate mt-1">{item.url}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default BookmarksView;
