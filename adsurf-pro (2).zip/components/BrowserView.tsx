
import React, { useState, useEffect, useMemo } from 'react';
import { BrowserConfig, BrowserTab, NewsItem, Transaction, SystemMessage } from '../types/config';
import AdSlot from './AdSlot';
import InterstitialOverlay from './InterstitialOverlay';
import MenuOverlay from './MenuOverlay';
import MissionCenter from './MissionCenter';
import ExitAdOverlay from './ExitAdOverlay';
import HistoryView from './HistoryView';
import BookmarksView from './BookmarksView';

interface BrowserViewProps {
  config: BrowserConfig;
  activeUrl: string;
  onNavigate: (url: string) => void;
  onUpdateConfig: (config: BrowserConfig) => void;
  onCollectReward: (amount: number, label: string, type?: Transaction['type']) => void;
}

const BrowserView: React.FC<BrowserViewProps> = ({ config, onUpdateConfig, onCollectReward }) => {
  const [currentView, setCurrentView] = useState<'home' | 'webview' | 'reader' | 'missions' | 'inbox' | 'ai-chat' | 'wallet' | 'games'>('home');
  const [homeSubTab, setHomeSubTab] = useState<'shortcuts' | 'discover' | 'memes'>('shortcuts');
  const [activeArticle, setActiveArticle] = useState<NewsItem | null>(null);
  const [rssData, setRssData] = useState<NewsItem[]>([]);
  
  const [showInterstitial, setShowInterstitial] = useState(false);
  const [navCount, setNavCount] = useState(0);

  const [tabs, setTabs] = useState<BrowserTab[]>([{ id: '1', url: 'adsurf://home', title: 'Home', history: [], historyIndex: 0, isDesktopMode: false, isIncognito: false }]);
  const [urlInput, setUrlInput] = useState('');
  
  const [showMenu, setShowMenu] = useState(false);
  const [showExitAd, setShowExitAd] = useState(false);
  const [activeOverlay, setActiveOverlay] = useState<'history' | 'bookmarks' | null>(null);
  const [activeNotification, setActiveNotification] = useState<SystemMessage | null>(null);

  const combinedPulse = useMemo(() => {
    return [...config.customArticles, ...rssData];
  }, [config.customArticles, rssData]);

  useEffect(() => {
    fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent('https://news.google.com/rss')}`)
      .then(res => res.json())
      .then(data => {
        if (data.status === 'ok') {
          const items = data.items.map((it: any) => ({
            id: it.guid, title: it.title, source: it.author || 'Global News', time: 'Just Now', category: 'General',
            imageUrl: it.thumbnail || it.enclosure?.link || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=400',
            content: it.description
          }));
          setRssData(items);
        }
      });
  }, []);

  // Listen for HQ messages
  useEffect(() => {
    const latest = config.userStats.messages[0];
    if (latest && !latest.isRead) {
      setActiveNotification(latest);
      setTimeout(() => setActiveNotification(null), 10000);
    }
  }, [config.userStats.messages]);

  const handleNavigate = (url: string) => {
    if (!url.trim()) return;
    const nextCount = navCount + 1;
    setNavCount(nextCount);
    // Show interstitial every 3 navigations now for higher monetization
    if (nextCount % 3 === 0) setShowInterstitial(true);

    if (url === 'adsurf://home') { setCurrentView('home'); return; }
    let final = url.includes('://') ? url : `https://www.google.com/search?q=${encodeURIComponent(url)}`;
    setTabs([{ ...tabs[0], url: final }]);
    setCurrentView('webview');
    setUrlInput('');
    onCollectReward(0.1, 'Browsing Reward', 'search');
  };

  const switchTab = (v: typeof currentView) => {
    // Navigating back to home or other views counts for ads
    if (v !== currentView) {
      setNavCount(prev => prev + 1);
      if ((navCount + 1) % 4 === 0) setShowInterstitial(true);
    }
    setCurrentView(v);
    setShowMenu(false);
  };

  const handleExitTrigger = () => {
    setShowMenu(false);
    if (config.adSettings.exitAdsEnabled) {
      const roll = Math.random() * 100;
      if (roll < config.adSettings.exitAdProbability) {
        setShowExitAd(true);
        return;
      }
    }
    window.close();
  };

  const gridItems = [
    { n: 'AI Chat', i: '✨', u: 'action:ai', color: 'bg-indigo-600' },
    { n: 'Wallet', i: '💰', u: 'action:wallet', color: 'bg-emerald-600' },
    { n: 'Games', i: '🎮', u: 'action:games', color: 'bg-rose-600' },
    { n: 'Weather', i: '🌤️', u: 'google.com/search?q=weather', color: 'bg-cyan-600' },
    { n: 'YouTube', i: '🎥', u: 'youtube.com', color: 'bg-red-600' },
    { n: 'News', i: '📰', u: 'news.google.com', color: 'bg-slate-800' },
    { n: 'Crypto', i: '🪙', u: 'coingecko.com', color: 'bg-amber-600' },
    { n: 'Facebook', i: '👤', u: 'facebook.com', color: 'bg-blue-800' },
    { n: 'Amazon', i: '🛒', u: 'amazon.com', color: 'bg-orange-600' },
    { n: 'Scanner', i: '📷', u: 'action:scanner', color: 'bg-slate-700' },
    { n: 'Music', i: '🎵', u: 'spotify.com', color: 'bg-green-600' },
    { n: 'Jobs', i: '💼', u: 'linkedin.com', color: 'bg-blue-700' },
  ];

  const handleGridAction = (u: string) => {
    if (u === 'action:ai') setCurrentView('ai-chat');
    else if (u === 'action:wallet') setCurrentView('wallet');
    else if (u === 'action:games') setCurrentView('games');
    else if (u === 'action:scanner') {
      alert("Scanner Node: Accessing Camera Hardware...");
      onCollectReward(0.5, 'Scanner Usage Reward', 'mission');
    }
    else handleNavigate(u);
  };

  return (
    <div className="flex flex-col h-full max-w-md mx-auto border-x border-slate-900 shadow-2xl relative bg-[#020617] text-slate-100 overflow-hidden">
      
      {/* GLOBAL NOTIFICATION */}
      {activeNotification && (
        <div className="fixed top-10 left-6 right-6 z-[1000] bg-indigo-600 border border-indigo-400 p-6 rounded-[35px] shadow-[0_30px_60px_rgba(79,70,229,0.5)] animate-slide-up flex items-center gap-5">
           <div className="text-3xl animate-bounce">📢</div>
           <div className="flex-1 min-w-0">
              <h4 className="text-sm font-black text-white italic truncate uppercase tracking-tighter">{activeNotification.title}</h4>
              <p className="text-[11px] text-white/80 line-clamp-1">{activeNotification.body}</p>
           </div>
           <button onClick={() => setActiveNotification(null)} className="text-white font-black">✕</button>
        </div>
      )}

      {showInterstitial && <InterstitialOverlay id={config.adSettings.interstitialId} onClose={() => setShowInterstitial(false)} />}
      
      <main className="flex-1 overflow-hidden relative">
        {currentView === 'home' && (
          <div className="h-full overflow-auto scrollbar-hide bg-[#020617] pb-48 animate-fade-in space-y-8">
             {/* Header Section */}
             <div className="px-10 flex flex-col items-center space-y-8 pt-12">
                <div className="relative group cursor-pointer active:scale-95 transition-all" onClick={() => switchTab('missions')}>
                  <span className="text-8xl animate-pulse block drop-shadow-[0_0_30px_rgba(79,70,229,0.4)]">{config.branding.appIcon}</span>
                  <div className="absolute -top-4 -right-8 bg-indigo-600 px-5 py-2 rounded-[22px] text-[12px] font-black italic shadow-2xl border border-indigo-400 flex flex-col items-center">
                    <span className="text-[7px] uppercase tracking-widest text-white/60 leading-none">Yield</span>
                    ₹ {config.userStats.balance.toFixed(2)}
                  </div>
                </div>
                
                <form onSubmit={e => { e.preventDefault(); handleNavigate(urlInput); }} className="w-full relative group">
                   <div className="absolute inset-0 bg-indigo-500/10 blur-3xl group-focus-within:bg-indigo-500/20 transition-all rounded-full"></div>
                   <input 
                      type="text" 
                      value={urlInput} 
                      onChange={e => setUrlInput(e.target.value)} 
                      className="w-full bg-slate-900/60 border border-white/5 rounded-[45px] py-6 px-10 text-sm font-bold text-white focus:outline-none focus:ring-4 focus:ring-indigo-500/20 shadow-2xl transition-all relative z-10 placeholder-slate-700" 
                      placeholder="Access decentralized nodes..." 
                   />
                   <button type="submit" className="absolute right-10 top-1/2 -translate-y-1/2 text-2xl text-indigo-500 z-10 hover:scale-110 transition-transform">🔍</button>
                </form>
             </div>

             <div className="px-8">
                <AdSlot type="banner" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.nativeId} />
             </div>

             <div className="px-10 space-y-8">
                <div className="flex gap-10 px-4 border-b border-white/5">
                   {['shortcuts', 'discover', 'memes'].map((tab: any) => (
                     <button 
                       key={tab} 
                       onClick={() => setHomeSubTab(tab)} 
                       className={`text-[11px] font-black uppercase tracking-[0.4em] pb-4 border-b-4 transition-all ${homeSubTab === tab ? 'text-indigo-400 border-indigo-400' : 'text-slate-800 border-transparent'}`}
                     >
                       {tab === 'shortcuts' ? 'Grid' : tab === 'discover' ? 'Pulse' : 'Viral'}
                     </button>
                   ))}
                </div>

                {homeSubTab === 'shortcuts' && (
                  <div className="space-y-10 animate-fade-in pb-32">
                    <div className="grid grid-cols-4 gap-8 px-2">
                      {gridItems.map((sc, idx) => (
                        <React.Fragment key={sc.n}>
                          <button onClick={() => handleGridAction(sc.u)} className="flex flex-col items-center gap-4 group">
                            <div className={`w-14 h-14 ${sc.color} rounded-[24px] border border-white/10 flex items-center justify-center text-2xl shadow-xl active:scale-90 transition-all border-b-4 border-black/30`}>
                               {sc.i}
                            </div>
                            <span className="text-[9px] font-black text-slate-500 uppercase tracking-tight truncate w-full text-center group-hover:text-indigo-400 transition-colors">{sc.n}</span>
                          </button>
                          {(idx + 1) % 4 === 0 && (
                             <div className="col-span-4 py-4">
                                <AdSlot type="in-post" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.nativeId} />
                             </div>
                          )}
                        </React.Fragment>
                      ))}
                    </div>
                    
                    <div className="space-y-6">
                       <span className="text-[10px] font-black text-slate-800 uppercase tracking-[0.5em] ml-6 block italic">Elite_Partner_Nodes</span>
                       <div className="grid grid-cols-1 gap-6">
                          <AdSlot type="large-rect" interval={15} adUnitId={config.adSettings.nativeId} />
                          <AdSlot type="in-post" interval={12} adUnitId={config.adSettings.rewardedId} />
                       </div>
                    </div>
                  </div>
                )}

                {homeSubTab === 'discover' && (
                  <div className="space-y-16 pb-32">
                     {combinedPulse.map((item, idx) => (
                       <React.Fragment key={item.id}>
                          <div onClick={() => { setActiveArticle(item); setCurrentView('reader'); onCollectReward(0.05, 'Reading Reward', 'read'); }} className={`rounded-[60px] border overflow-hidden transition-all shadow-[0_40px_80px_rgba(0,0,0,0.7)] group cursor-pointer ${item.isCustom ? 'bg-indigo-950/20 border-indigo-500/40' : 'bg-slate-900/40 border-white/5 hover:border-indigo-500/30'}`}>
                             <div className="relative h-80 overflow-hidden">
                                <img src={item.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[3s]" />
                                <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-90"></div>
                                <div className="absolute bottom-10 left-10 flex items-center gap-4">
                                   <div className="w-2.5 h-2.5 bg-indigo-500 rounded-full animate-ping"></div>
                                   <span className="text-[11px] font-black text-indigo-400 uppercase tracking-[0.3em] italic">{item.source}</span>
                                </div>
                             </div>
                             <div className="p-12 space-y-6">
                                <h4 className="text-3xl font-black text-white italic tracking-tighter leading-tight group-hover:text-indigo-300 transition-colors line-clamp-3 uppercase">{item.title}</h4>
                                <p className="text-slate-500 text-xs font-medium line-clamp-2 leading-relaxed opacity-60">Transmission decrypted. Open node for full data access...</p>
                             </div>
                          </div>
                          {/* SHOW AD AFTER EVERY 1 POST */}
                          <div className="py-2">
                             {idx % 3 === 0 && <AdSlot type="in-post" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.inFeedNativeId} />}
                             {idx % 3 === 1 && <AdSlot type="large-rect" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.nativeId} />}
                             {idx % 3 === 2 && <AdSlot type="banner" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.bannerId} />}
                          </div>
                       </React.Fragment>
                     ))}
                  </div>
                )}

                {homeSubTab === 'memes' && (
                  <div className="space-y-20 pb-32">
                     {config.memes.map((m, idx) => (
                       <React.Fragment key={m.id}>
                          <div className="bg-slate-900/50 rounded-[65px] border border-white/5 overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.8)]">
                             <div className="relative aspect-square">
                                <img src={m.imageUrl} className="w-full h-full object-cover" />
                             </div>
                             <div className="p-12 flex justify-between items-center bg-slate-900">
                                <div className="space-y-2">
                                   <h5 className="text-2xl font-black text-white italic uppercase tracking-tighter">{m.title}</h5>
                                   <span className="text-[10px] text-indigo-500 font-black uppercase tracking-[0.4em]">Viral Node Sync</span>
                                </div>
                                <button onClick={() => onCollectReward(0.05, 'Meme Sentiment Reward', 'meme')} className="w-20 h-20 bg-indigo-600 rounded-[35px] flex items-center justify-center text-4xl shadow-2xl shadow-indigo-600/30 active:scale-75 transition-all">🔥</button>
                             </div>
                          </div>
                          {/* SHOW AD AFTER EVERY 1 MEME */}
                          <div className="py-2">
                            {idx % 2 === 0 ? (
                               <AdSlot type="large-rect" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.nativeId} />
                            ) : (
                               <AdSlot type="in-post" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.rewardedId} />
                            )}
                          </div>
                       </React.Fragment>
                     ))}
                  </div>
                )}
             </div>
          </div>
        )}

        {currentView === 'webview' && <iframe src={tabs[0].url} className="w-full h-full border-0 bg-white" />}

        {currentView === 'ai-chat' && (
           <div className="h-full bg-[#020617] flex flex-col p-10 animate-fade-in">
              <header className="flex justify-between items-center mb-10">
                 <button onClick={() => setCurrentView('home')} className="text-slate-500 font-black uppercase text-[10px] tracking-widest">← Back</button>
                 <span className="text-indigo-400 font-black uppercase text-[10px] tracking-[0.5em] italic">AI_Neural_Node</span>
              </header>
              <div className="flex-1 overflow-auto space-y-6 scrollbar-hide">
                 <div className="p-8 bg-slate-900/40 rounded-[40px] border border-indigo-500/20 max-w-[85%] self-start">
                    <p className="text-sm font-medium text-slate-300">Operational. I am the Surf_OPS intelligence core. How can I assist your browsing session today?</p>
                 </div>
                 <AdSlot type="native" interval={15} adUnitId={config.adSettings.nativeId} />
              </div>
              <div className="pt-6 relative">
                 <input type="text" className="w-full bg-slate-900 border border-white/5 rounded-[30px] py-6 px-10 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/50" placeholder="Type prompt..." />
                 <button className="absolute right-6 top-1/2 -translate-y-1/2 text-2xl">✨</button>
              </div>
           </div>
        )}

        {currentView === 'wallet' && (
           <div className="h-full bg-[#020617] p-10 space-y-10 animate-fade-in overflow-auto scrollbar-hide">
              <header className="flex justify-between items-center">
                 <button onClick={() => setCurrentView('home')} className="text-slate-500 font-black text-[10px] tracking-widest uppercase">← Exit_Vault</button>
                 <span className="bg-emerald-500/10 text-emerald-500 px-4 py-1.5 rounded-full border border-emerald-500/20 text-[10px] font-black uppercase tracking-widest">Sync_Safe</span>
              </header>
              <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-[50px] p-12 space-y-8 shadow-2xl shadow-indigo-600/20 relative overflow-hidden">
                 <div className="absolute -top-10 -right-10 text-[180px] opacity-10 blur-xl">💰</div>
                 <div className="relative z-10 space-y-2">
                    <span className="text-[10px] font-black text-indigo-300 uppercase tracking-widest">Available Node Credits</span>
                    <h2 className="text-6xl font-black text-white italic tracking-tighter leading-none">₹ {config.userStats.balance.toFixed(2)}</h2>
                 </div>
                 <div className="relative z-10 grid grid-cols-2 gap-4">
                    <button className="bg-white/10 backdrop-blur-md border border-white/20 py-4 rounded-[25px] text-[10px] font-black uppercase tracking-widest">Withdraw</button>
                    <button className="bg-white text-indigo-900 py-4 rounded-[25px] text-[10px] font-black uppercase tracking-widest">History</button>
                 </div>
              </div>
              <AdSlot type="large-rect" interval={20} adUnitId={config.adSettings.bannerId} />
           </div>
        )}

        {currentView === 'games' && (
           <div className="h-full bg-[#020617] p-10 space-y-10 animate-fade-in overflow-auto scrollbar-hide">
              <header className="flex justify-between items-center">
                 <button onClick={() => setCurrentView('home')} className="text-slate-500 font-black text-[10px] tracking-widest uppercase">← Back</button>
                 <span className="text-rose-500 font-black text-[10px] tracking-[0.5em] italic">Gaming_Zone</span>
              </header>
              <div className="grid grid-cols-2 gap-6">
                 {['Retro Hub', 'Yield Dash', 'Crypto Spin', 'Ad Blast'].map(game => (
                    <div key={game} onClick={() => onCollectReward(0.2, 'Game Engagement Reward', 'mission')} className="aspect-square bg-slate-900 border border-white/5 rounded-[40px] flex flex-col items-center justify-center gap-4 group cursor-pointer hover:border-rose-500/40 transition-all">
                       <span className="text-5xl group-hover:scale-110 transition-transform">🎮</span>
                       <span className="text-[10px] font-black text-white uppercase tracking-widest">{game}</span>
                    </div>
                 ))}
              </div>
              <AdSlot type="video" interval={30} adUnitId={config.adSettings.rewardedId} />
           </div>
        )}

        {currentView === 'reader' && activeArticle && (
          <div className="h-full bg-[#020617] overflow-auto scrollbar-hide p-12 animate-fade-in space-y-16 pb-64">
             <button onClick={() => setCurrentView('home')} className="p-8 bg-slate-900/50 rounded-[35px] text-[12px] font-black uppercase tracking-[0.5em] text-slate-500 border border-white/5 hover:text-white transition-all shadow-2xl">← Back_Feed</button>
             <AdSlot type="banner" interval={10} adUnitId={config.adSettings.nativeArticleId} />
             <div className="space-y-8">
               <img src={activeArticle.imageUrl} className="w-full rounded-[70px] shadow-[0_50px_100px_rgba(0,0,0,0.9)] border border-white/10" />
               <div className="flex items-center gap-4">
                  <div className="w-10 h-1 bg-indigo-600 rounded-full"></div>
                  <span className="text-[11px] font-black text-indigo-400 uppercase tracking-[0.6em]">{activeArticle.source}</span>
               </div>
               <h1 className="text-5xl font-black text-white italic tracking-tighter leading-[0.9] uppercase">{activeArticle.title}</h1>
             </div>
             <div className="text-slate-400 text-xl leading-relaxed font-medium space-y-10 border-t border-white/5 pt-10" dangerouslySetInnerHTML={{ __html: activeArticle.content }} />
             <AdSlot type="large-rect" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.nativeArticleId} />
          </div>
        )}

        {currentView === 'missions' && <MissionCenter userStats={config.userStats} onClaim={() => {}} onClose={() => setCurrentView('home')} currency={config.preferences.currency} />}

        {currentView === 'inbox' && (
           <div className="h-full bg-[#020617] p-12 space-y-16 animate-fade-in overflow-auto pb-64 scrollbar-hide">
              <button onClick={() => setCurrentView('home')} className="p-8 bg-slate-900/50 rounded-[35px] text-[12px] font-black uppercase text-slate-500 tracking-[0.5em] border border-white/5 shadow-2xl">← Close_Relay</button>
              <h2 className="text-7xl font-black text-white italic tracking-tighter uppercase leading-none">HQ_Dispatches</h2>
              <AdSlot type="banner" interval={20} adUnitId={config.adSettings.bannerId} />
              <div className="space-y-12">
                 {config.userStats.messages.map(m => (
                   <div key={m.id} className="p-16 bg-slate-900/40 backdrop-blur-3xl border border-white/5 rounded-[70px] space-y-10 shadow-[0_60px_120px_rgba(0,0,0,0.8)] border-l-8 border-l-indigo-600">
                      <div className="flex justify-between items-center">
                         <span className="text-[11px] font-black text-indigo-400 uppercase tracking-[0.6em] italic">{new Date(m.timestamp).toLocaleTimeString()}</span>
                         <span className={`text-[10px] font-black uppercase px-6 py-2 rounded-full italic ${m.type === 'urgent' ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/40' : 'bg-slate-800 text-slate-500'}`}>{m.type}</span>
                      </div>
                      <div className="space-y-4">
                        <h3 className="text-4xl font-black text-white italic leading-tight uppercase tracking-tighter">{m.title}</h3>
                        <p className="text-xl text-slate-400 leading-relaxed font-medium opacity-80">{m.body}</p>
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        )}
      </main>

      {/* STICKY REVENUE BAR */}
      {currentView === 'home' && <AdSlot type="banner" interval={config.adSettings.refreshInterval} adUnitId={config.adSettings.stickyBannerId} />}

      <nav className="px-10 py-10 flex items-center justify-between bg-[#020617]/95 backdrop-blur-3xl border-t border-white/5 z-50">
         <button onClick={() => switchTab('home')} className={`p-6 rounded-[28px] transition-all duration-700 ${currentView === 'home' ? 'bg-indigo-600 text-white shadow-[0_25px_60px_rgba(79,70,229,0.5)] scale-110' : 'text-slate-800 hover:text-slate-500'}`}>🏠</button>
         <button onClick={() => switchTab('ai-chat')} className={`p-6 rounded-[28px] transition-all duration-700 ${currentView === 'ai-chat' ? 'bg-indigo-600 text-white shadow-[0_25px_60px_rgba(79,70,229,0.5)] scale-110' : 'text-slate-800 hover:text-slate-500'}`}>✨</button>
         <button onClick={() => switchTab('wallet')} className={`p-6 rounded-[28px] transition-all duration-700 ${currentView === 'wallet' ? 'bg-indigo-600 text-white shadow-[0_25px_60px_rgba(79,70,229,0.5)] scale-110' : 'text-slate-800 hover:text-slate-500'}`}>💰</button>
         <button onClick={() => setShowMenu(true)} className="p-6 text-slate-800 text-3xl font-black hover:text-white transition-colors">≡</button>
      </nav>

      {showMenu && <MenuOverlay isDesktop={false} isDarkMode={true} isPerformanceMode={false} isAdBlockerActive={config.preferences.adBlockerActive} currency={config.preferences.currency} onToggleDesktop={() => {}} onToggleTheme={() => {}} onTogglePerformance={() => {}} onToggleAdBlocker={() => {}} onToggleCurrency={() => {}} onNewTab={() => { switchTab('home'); }} onOpenDownloads={() => {}} onOpenHistory={() => setActiveOverlay('history')} onOpenBookmarks={() => setActiveOverlay('bookmarks')} onOpenOffline={() => {}} onAddBookmark={() => {}} onSaveOffline={() => {}} onExitApp={handleExitTrigger} onClose={() => setShowMenu(false)} />}
      {activeOverlay === 'history' && <HistoryView items={config.userStats.historyItems || []} onNavigate={handleNavigate} onClose={() => setActiveOverlay(null)} />}
      {activeOverlay === 'bookmarks' && <BookmarksView items={config.userStats.bookmarks || []} onNavigate={handleNavigate} onClose={() => setActiveOverlay(null)} />}
      {showExitAd && <ExitAdOverlay onStay={() => setShowExitAd(false)} onExit={() => { window.close(); }} />}
    </div>
  );
};

export default BrowserView;
