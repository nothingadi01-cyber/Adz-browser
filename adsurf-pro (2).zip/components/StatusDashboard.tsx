
import React from 'react';

interface StatusDashboardProps {
  isReady: boolean;
}

export const StatusDashboard: React.FC<StatusDashboardProps> = ({ isReady }) => {
  return (
    <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-8 shadow-2xl space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-800 pb-8">
        <div>
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-indigo-400">
            System Status: Ready
          </h1>
          <p className="text-slate-400 mt-2 font-light">
            Senior Frontend Engineer & Gemini Specialist Instance
          </p>
        </div>
        <div className="flex items-center gap-3 bg-emerald-500/10 text-emerald-400 px-4 py-2 rounded-full border border-emerald-500/20">
          <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></div>
          <span className="text-sm font-semibold tracking-tighter">I AM READY</span>
        </div>
      </div>

      {/* Grid of Capabilities */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatusCard 
          title="React 18 & TS" 
          status="Operational" 
          description="Ready to scaffold robust SPAs with full type safety."
          color="blue"
        />
        <StatusCard 
          title="Gemini SDK" 
          status="Configured" 
          description="Advanced GenAI integration patterns pre-flighted."
          color="indigo"
        />
        <StatusCard 
          title="Tailwind UI" 
          status="Loaded" 
          description="High-fidelity design system and utility classes active."
          color="purple"
        />
      </div>

      {/* Intake Placeholder */}
      <div className="bg-slate-950/50 rounded-xl p-6 border border-slate-800/50 flex flex-col items-center justify-center text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center animate-bounce">
          <svg className="w-8 h-8 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
          </svg>
        </div>
        <div>
          <h3 className="text-xl font-medium text-slate-200">Awaiting PRD & Implementation Plan</h3>
          <p className="text-slate-500 mt-1 max-w-sm mx-auto">
            Provide your documents in the next prompt. I will immediately begin generating the full-scale mobile application environment.
          </p>
        </div>
      </div>
    </div>
  );
};

interface StatusCardProps {
  title: string;
  status: string;
  description: string;
  color: 'blue' | 'indigo' | 'purple';
}

const StatusCard: React.FC<StatusCardProps> = ({ title, status, description, color }) => {
  const colorMap = {
    blue: 'border-blue-500/30 text-blue-400 bg-blue-500/5',
    indigo: 'border-indigo-500/30 text-indigo-400 bg-indigo-500/5',
    purple: 'border-purple-500/30 text-purple-400 bg-purple-500/5',
  };

  return (
    <div className={`p-5 rounded-xl border ${colorMap[color]} space-y-3 transition-transform hover:scale-105 duration-300`}>
      <div className="flex items-center justify-between">
        <span className="font-bold text-sm uppercase tracking-widest">{title}</span>
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md border border-current">{status}</span>
      </div>
      <p className="text-xs leading-relaxed text-slate-400">{description}</p>
    </div>
  );
};
