
import React, { useState } from 'react';
import { BrowserConfig, SearchEngine, FontFamily } from '../types/config';

interface SetupWizardProps {
  config: BrowserConfig;
  onComplete: (config: BrowserConfig) => void;
}

const SetupWizard: React.FC<SetupWizardProps> = ({ config, onComplete }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<BrowserConfig>(config);

  const colors = [
    { name: 'Indigo', class: 'bg-indigo-600', val: 'indigo' },
    { name: 'Rose', class: 'bg-rose-600', val: 'rose' },
    { name: 'Emerald', class: 'bg-emerald-600', val: 'emerald' },
    { name: 'Amber', class: 'bg-amber-600', val: 'amber' },
    { name: 'Purple', class: 'bg-purple-600', val: 'purple' },
    { name: 'Cyan', class: 'bg-cyan-600', val: 'cyan' },
  ];

  const icons = ["🌐", "🚀", "⚡", "🕶️", "🦁", "🦊", "🐬", "🦢"];
  const searchEngines: { id: SearchEngine; name: string; url: string }[] = [
    { id: 'google', name: 'Google', url: 'https://www.google.com' },
    { id: 'bing', name: 'Bing', url: 'https://www.bing.com' },
    { id: 'duckduckgo', name: 'DuckDuckGo', url: 'https://duckduckgo.com' },
  ];
  const fonts: { id: FontFamily; name: string }[] = [
    { id: 'sans', name: 'Modern Sans' },
    { id: 'serif', name: 'Classic Serif' },
    { id: 'mono', name: 'Developer Mono' },
  ];

  const handleFinish = () => {
    onComplete({ ...formData, isInitialized: true });
  };

  const next = () => setStep(s => s + 1);
  const prev = () => setStep(s => s - 1);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 flex items-center justify-center p-4">
      <div className="max-w-xl w-full bg-slate-900/50 backdrop-blur-2xl border border-slate-800 rounded-3xl shadow-2xl overflow-hidden animate-fade-in">
        
        {/* Progress Bar */}
        <div className="h-1 bg-slate-800 flex">
          {[1, 2, 3, 4, 5].map(i => (
            <div 
              key={i} 
              className={`flex-1 transition-all duration-500 ${step >= i ? `bg-${formData.themeColor}-600` : 'bg-transparent'}`}
            />
          ))}
        </div>

        <div className="p-8 md:p-12 space-y-8">
          {step === 1 && (
            <div className="space-y-6 animate-fade-in">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tight">Project Identity</h2>
                <p className="text-slate-400">Define your app's name and package identifier.</p>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">App Name</label>
                  <input 
                    type="text" 
                    value={formData.appName}
                    onChange={e => setFormData({...formData, appName: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                    placeholder="e.g. AdSurf Browser"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Package Name</label>
                  <input 
                    type="text" 
                    value={formData.packageName}
                    onChange={e => setFormData({...formData, packageName: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all font-mono text-sm"
                    placeholder="com.company.browser"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6 animate-fade-in">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tight">App Personality</h2>
                <p className="text-slate-400">Choose an icon and primary search engine.</p>
              </div>
              <div className="space-y-4">
                <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">App Icon</label>
                <div className="grid grid-cols-4 gap-3">
                  {icons.map(icon => (
                    <button 
                      key={icon}
                      onClick={() => setFormData({...formData, branding: {...formData.branding, appIcon: icon}})}
                      className={`h-16 rounded-2xl border-2 flex items-center justify-center text-2xl transition-all ${formData.branding.appIcon === icon ? 'border-white bg-slate-800 scale-105' : 'border-slate-800 hover:border-slate-700'}`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
                
                <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 mt-6">Default Search Engine</label>
                <div className="space-y-2">
                  {searchEngines.map(engine => (
                    <button 
                      key={engine.id}
                      onClick={() => setFormData({...formData, branding: {...formData.branding, searchEngine: engine.id}, homepageUrl: engine.url})}
                      className={`w-full p-4 rounded-xl border-2 text-left flex items-center justify-between transition-all ${formData.branding.searchEngine === engine.id ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-800 hover:border-slate-700'}`}
                    >
                      <span className="font-bold">{engine.name}</span>
                      {formData.branding.searchEngine === engine.id && <span className="text-indigo-500">✓</span>}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6 animate-fade-in">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tight">Visual Style</h2>
                <p className="text-slate-400">Select the primary theme color and typography.</p>
              </div>
              <div className="grid grid-cols-3 gap-4">
                {colors.map(c => (
                  <button 
                    key={c.val}
                    onClick={() => setFormData({...formData, themeColor: c.val})}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-3 ${formData.themeColor === c.val ? 'border-white bg-slate-800' : 'border-slate-800 hover:border-slate-700'}`}
                  >
                    <div className={`w-8 h-8 rounded-full ${c.class} shadow-lg shadow-${c.val}-500/20`} />
                    <span className="text-[10px] font-bold uppercase tracking-tighter">{c.name}</span>
                  </button>
                ))}
              </div>

              <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 mt-6">Typography</label>
              <div className="grid grid-cols-1 gap-3">
                {fonts.map(font => (
                  <button 
                    key={font.id}
                    onClick={() => setFormData({...formData, branding: {...formData.branding, fontFamily: font.id}})}
                    className={`p-4 rounded-xl border-2 text-left flex items-center justify-between transition-all ${formData.branding.fontFamily === font.id ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-800 hover:border-slate-700'}`}
                  >
                    <span className={`font-bold ${font.id === 'mono' ? 'font-mono' : font.id === 'serif' ? 'font-serif' : 'font-sans'}`}>{font.name}</span>
                    {formData.branding.fontFamily === font.id && <span className="text-indigo-500">✓</span>}
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6 animate-fade-in">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tight">Monetization</h2>
                <p className="text-slate-400">Configure your primary ad network settings.</p>
              </div>
              <div className="space-y-4 h-[400px] overflow-y-auto pr-4 scrollbar-hide">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">AdMob App ID</label>
                  <input 
                    type="text" 
                    value={formData.adSettings.adMobId}
                    onChange={e => setFormData({
                      ...formData, 
                      adSettings: { ...formData.adSettings, adMobId: e.target.value }
                    })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Banner Unit ID</label>
                  <input 
                    type="text" 
                    value={formData.adSettings.bannerId}
                    onChange={e => setFormData({
                      ...formData, 
                      adSettings: { ...formData.adSettings, bannerId: e.target.value }
                    })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Interstitial Unit ID</label>
                  <input 
                    type="text" 
                    value={formData.adSettings.interstitialId}
                    onChange={e => setFormData({
                      ...formData, 
                      adSettings: { ...formData.adSettings, interstitialId: e.target.value }
                    })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Rewarded Unit ID</label>
                  <input 
                    type="text" 
                    value={formData.adSettings.rewardedId}
                    onChange={e => setFormData({
                      ...formData, 
                      adSettings: { ...formData.adSettings, rewardedId: e.target.value }
                    })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">App Open Unit ID</label>
                  <input 
                    type="text" 
                    value={formData.adSettings.appOpenId}
                    onChange={e => setFormData({
                      ...formData, 
                      adSettings: { ...formData.adSettings, appOpenId: e.target.value }
                    })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all font-mono text-xs"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-6 animate-fade-in">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tight">Review & Launch</h2>
                <p className="text-slate-400">Final check of your browser configuration.</p>
              </div>
              
              <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800 space-y-4">
                 <div className="flex items-center gap-4">
                    <div className={`w-16 h-16 rounded-2xl bg-${formData.themeColor}-600 flex items-center justify-center text-white text-3xl shadow-xl shadow-${formData.themeColor}-600/30`}>
                      {formData.branding.appIcon}
                    </div>
                    <div>
                      <div className="text-xl font-black text-white">{formData.appName}</div>
                      <div className="text-xs text-slate-500 font-mono">{formData.packageName}</div>
                    </div>
                 </div>
                 
                 <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-800">
                    <div>
                       <span className="block text-[10px] text-slate-500 uppercase font-black">Search Engine</span>
                       <span className="text-sm font-bold text-slate-300 capitalize">{formData.branding.searchEngine}</span>
                    </div>
                    <div>
                       <span className="block text-[10px] text-slate-500 uppercase font-black">Typography</span>
                       <span className="text-sm font-bold text-slate-300 capitalize">{formData.branding.fontFamily}</span>
                    </div>
                 </div>
              </div>

              <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-xl flex gap-3">
                <span className="text-emerald-500 mt-0.5">🚀</span>
                <p className="text-[11px] text-emerald-500/80 leading-relaxed">
                  Your AdSurf engine is pre-flighted and ready for deployment. Click launch to initialize the browser environment.
                </p>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between pt-8 border-t border-slate-800">
            {step > 1 ? (
              <button onClick={prev} className="text-slate-400 hover:text-white transition-colors text-sm font-bold">
                Back
              </button>
            ) : <div />}
            
            {step < 5 ? (
              <button 
                onClick={next}
                className={`bg-${formData.themeColor}-600 hover:opacity-90 px-8 py-3 rounded-xl font-bold transition-all shadow-xl shadow-${formData.themeColor}-600/20`}
              >
                Next Step
              </button>
            ) : (
              <button 
                onClick={handleFinish}
                className={`bg-${formData.themeColor}-600 hover:opacity-90 px-8 py-3 rounded-xl font-bold transition-all shadow-xl shadow-${formData.themeColor}-600/20`}
              >
                Launch Browser
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SetupWizard;
