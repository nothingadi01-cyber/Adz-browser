
import React, { useState, useEffect } from 'react';
import { BrowserConfig, NewsItem, MemeItem, SystemMessage, SupportTicket } from '../types/config';

interface AdminDashboardProps {
  config: BrowserConfig;
  onUpdate: (config: BrowserConfig) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ config, onUpdate }) => {
  const [localConfig, setLocalConfig] = useState(config);
  const [activePanel, setActivePanel] = useState<'analytics' | 'inventory' | 'creator' | 'users' | 'support' | 'system'>('analytics');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");

  // Sync with parent config updates (e.g., if balance changes while admin is open)
  useEffect(() => {
    setLocalConfig(config);
  }, [config]);

  // Creator Forms
  const [newsForm, setNewsForm] = useState({ title: '', content: '', img: '' });
  const [memeForm, setMemeForm] = useState({ title: '', img: '' });

  // Analytics Jitter
  const [liveRevenue, setLiveRevenue] = useState(config.analytics.revenue);

  useEffect(() => {
    if (activePanel === 'analytics') {
      const interval = setInterval(() => {
        setLiveRevenue(prev => prev + (Math.random() * 0.02));
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [activePanel]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "admin123") setIsAuthenticated(true);
    else alert("LOGIN FAILED: INCORRECT COMMAND KEY.");
  };

  const save = (next: BrowserConfig) => {
    setLocalConfig(next);
    onUpdate(next);
  };

  const updateAdSetting = (key: keyof typeof localConfig.adSettings, value: any) => {
    save({ ...localConfig, adSettings: { ...localConfig.adSettings, [key]: value } });
  };

  const updateSystemSetting = (key: keyof typeof localConfig.system, value: any) => {
    save({ ...localConfig, system: { ...localConfig.system, [key]: value } });
  };

  const toggleAdFormat = (key: keyof typeof localConfig.adSettings) => {
    updateAdSetting(key, !localConfig.adSettings[key]);
  };

  const resolveTicket = (id: string) => {
    const nextTickets = localConfig.supportTickets.map(t => 
      t.id === id ? { ...t, status: 'resolved' as const } : t
    );
    save({ ...localConfig, supportTickets: nextTickets });
  };

  const overrideUserStat = (key: keyof typeof localConfig.userStats, value: any) => {
    save({
      ...localConfig,
      userStats: { ...localConfig.userStats, [key]: value }
    });
  };

  const publishNews = () => {
    if (!newsForm.title || !newsForm.content) return;
    const newItem: NewsItem = {
      id: 'pub_' + Date.now(),
      title: newsForm.title,
      source: localConfig.appName + ' Admin',
      time: 'Just Now',
      category: 'Broadcast',
      imageUrl: newsForm.img || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=400',
      content: newsForm.content,
      isCustom: true
    };
    save({ ...localConfig, customArticles: [newItem, ...localConfig.customArticles] });
    setNewsForm({ title: '', content: '', img: '' });
    alert("NEWS BROADCAST DEPLOYED");
  };

  const publishMeme = () => {
    if (!memeForm.img) return;
    const newItem: MemeItem = {
      id: 'viral_' + Date.now(),
      title: memeForm.title || 'Broadcast Signal',
      imageUrl: memeForm.img,
      likes: 0,
      timestamp: Date.now()
    };
    save({ ...localConfig, memes: [newItem, ...localConfig.memes] });
    setMemeForm({ title: '', img: '' });
    alert("VIRAL NODE INJECTED");
  };

  if (!isAuthenticated) {
    return (
      <div className="h-full bg-slate-950 flex items-center justify-center p-6 font-mono">
        <div className="max-w-sm w-full bg-slate-900 border border-indigo-500/20 rounded-[40px] p-10 space-y-8 shadow-2xl animate-scale-in">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-indigo-600 rounded-3xl mx-auto flex items-center justify-center text-white text-3xl font-black shadow-lg">🔐</div>
            <h2 className="text-xl font-black text-white italic tracking-tighter uppercase">ADMIN_ACCESS</h2>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <input 
              type="password" 
              value={password} 
              onChange={e => setPassword(e.target.value)} 
              className="w-full bg-slate-950 border border-white/5 rounded-2xl px-6 py-4 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 text-center tracking-[0.5em] text-white" 
              placeholder="••••" 
            />
            <button className="w-full bg-indigo-600 py-4 rounded-2xl font-black text-white uppercase tracking-widest text-[10px] hover:bg-indigo-500 transition-all">Authorize</button>
          </form>
        </div>
      </div>
    );
  }

  const panels = [
    { id: 'analytics', icon: '📊', label: 'Metrics' },
    { id: 'inventory', icon: '🏷️', label: 'Ads' },
    { id: 'creator', icon: '✍️', label: 'Creator' },
    { id: 'users', icon: '👥', label: 'Users' },
    { id: 'support', icon: '🎧', label: 'Support' },
    { id: 'system', icon: '⚙️', label: 'System' },
  ] as const;

  return (
    <div className="h-full bg-[#020617] flex flex-col md:flex-row overflow-hidden relative font-sans">
      
      {/* DESKTOP SIDEBAR */}
      <aside className="hidden md:flex w-64 bg-slate-900/50 backdrop-blur-3xl border-r border-white/5 flex-col p-6 space-y-2 overflow-y-auto">
        <div className="p-4 border-b border-white/5 mb-8">
           <h1 className="text-xl font-black text-white italic tracking-tighter uppercase leading-none">Surf<span className="text-indigo-500">_OPS</span></h1>
        </div>
        {panels.map(p => (
          <NavItem key={p.id} icon={p.icon} label={p.label} active={activePanel === p.id} onClick={() => setActivePanel(p.id)} />
        ))}
      </aside>

      {/* MOBILE TOP BAR */}
      <div className="md:hidden flex items-center justify-between p-6 bg-slate-900 border-b border-white/5">
         <h1 className="text-lg font-black text-white italic tracking-tighter uppercase">Surf<span className="text-indigo-500">_OPS</span></h1>
         <div className="bg-indigo-600/20 px-3 py-1 rounded-full border border-indigo-500/30 text-[9px] font-black text-indigo-400 uppercase">Live_HQ</div>
      </div>

      {/* MAIN AREA */}
      <main className="flex-1 overflow-auto p-6 md:p-12 pb-32 scrollbar-hide">
        
        {activePanel === 'analytics' && (
          <div className="space-y-10 animate-fade-in">
            <header className="space-y-1">
              <h2 className="text-3xl font-black text-white tracking-tighter italic uppercase">Grid_Telemetry</h2>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em]">Real-time Network Stats</p>
            </header>
            
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
               <StatCard label="Live Nodes" value={localConfig.analytics.dau} color="text-indigo-400" pulse />
               <StatCard label="Live Yield" value={liveRevenue.toFixed(2)} prefix="₹" color="text-emerald-400" />
               <StatCard label="Global CTR" value={localConfig.analytics.ctr} suffix="%" color="text-amber-400" />
               <StatCard label="Payouts" value={localConfig.analytics.totalRewardsPaid} prefix="₹" color="text-rose-400" />
            </div>

            <div className="bg-slate-900/40 border border-white/5 rounded-[40px] p-6 md:p-10 space-y-6">
              <h3 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest italic">7-Session Performance</h3>
              <div className="flex items-end gap-2 h-40">
                 {localConfig.analytics.history.map((h, i) => (
                   <div key={i} className="flex-1 bg-indigo-600/30 rounded-t-xl hover:bg-indigo-500 transition-all cursor-crosshair relative group" style={{ height: `${h}%` }}>
                      <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 px-2 py-1 rounded text-[8px] opacity-0 group-hover:opacity-100 transition-opacity border border-white/5 text-white">{h}%</div>
                   </div>
                 ))}
              </div>
            </div>
          </div>
        )}

        {activePanel === 'inventory' && (
          <div className="space-y-10 animate-fade-in">
            <header className="space-y-1">
              <h2 className="text-3xl font-black text-white tracking-tighter italic uppercase">Ad_Registry</h2>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em]">Node Monetization Control</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
               <AdminSection title="Format Toggles" color="text-emerald-400">
                  <ToggleRow label="Splash (App Open)" active={localConfig.adSettings.splashEnabled} onToggle={() => toggleAdFormat('splashEnabled')} />
                  <ToggleRow label="Standard Banners" active={localConfig.adSettings.bannersEnabled} onToggle={() => toggleAdFormat('bannersEnabled')} />
                  <ToggleRow label="Interstitials" active={localConfig.adSettings.interstitialsEnabled} onToggle={() => toggleAdFormat('interstitialsEnabled')} />
                  <ToggleRow label="Rewarded Ads" active={localConfig.adSettings.rewardedEnabled} onToggle={() => toggleAdFormat('rewardedEnabled')} />
               </AdminSection>

               <AdminSection title="Unit IDs" color="text-indigo-400">
                  <AdIdInput label="Application ID" value={localConfig.adSettings.adMobId} onChange={v => updateAdSetting('adMobId', v)} />
                  <AdIdInput label="Banner Unit" value={localConfig.adSettings.bannerId} onChange={v => updateAdSetting('bannerId', v)} />
                  <AdIdInput label="Interstitial Unit" value={localConfig.adSettings.interstitialId} onChange={v => updateAdSetting('interstitialId', v)} />
                  <AdIdInput label="Rewarded Unit" value={localConfig.adSettings.rewardedId} onChange={v => updateAdSetting('rewardedId', v)} />
               </AdminSection>
            </div>
          </div>
        )}

        {activePanel === 'creator' && (
          <div className="space-y-10 animate-fade-in">
            <header className="space-y-1">
              <h2 className="text-3xl font-black text-white tracking-tighter italic uppercase">Creator_Studio</h2>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em]">Inject Custom Nodes</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
               <AdminSection title="Pulse Publisher" color="text-indigo-400">
                  <AdIdInput label="Title" value={newsForm.title} onChange={v => setNewsForm({...newsForm, title: v})} />
                  <AdIdInput label="Image URL" value={newsForm.img} onChange={v => setNewsForm({...newsForm, img: v})} />
                  <textarea value={newsForm.content} onChange={e => setNewsForm({...newsForm, content: e.target.value})} className="w-full bg-slate-950 border border-white/5 rounded-2xl p-4 text-xs text-white outline-none min-h-[100px]" placeholder="Article content..."></textarea>
                  <button onClick={publishNews} className="w-full bg-indigo-600 py-4 rounded-xl text-[10px] font-black text-white uppercase tracking-widest">Broadcast News</button>
               </AdminSection>

               <AdminSection title="Meme Infiltrator" color="text-rose-400">
                  <AdIdInput label="Caption" value={memeForm.title} onChange={v => setMemeForm({...memeForm, title: v})} />
                  <AdIdInput label="Meme URL" value={memeForm.img} onChange={v => setMemeForm({...memeForm, img: v})} />
                  <button onClick={publishMeme} className="w-full bg-rose-600 py-4 rounded-xl text-[10px] font-black text-white uppercase tracking-widest">Inject Meme</button>
               </AdminSection>
            </div>
          </div>
        )}

        {activePanel === 'users' && (
          <div className="space-y-10 animate-fade-in">
            <header className="space-y-1">
              <h2 className="text-3xl font-black text-white tracking-tighter italic uppercase">User_Ops</h2>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em]">Manual Stat Overrides</p>
            </header>

            <div className="bg-slate-900 border border-white/5 rounded-[40px] p-8 space-y-8 shadow-xl">
               <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-indigo-600 rounded-[25px] flex items-center justify-center text-3xl">👤</div>
                  <div>
                    <h3 className="text-xl font-black text-white">{localConfig.userStats.referralCode}</h3>
                    <p className="text-[10px] text-indigo-500 font-black uppercase">Active Browser Node</p>
                  </div>
               </div>

               <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <OverrideButton label="+ ₹10.00" onClick={() => overrideUserStat('balance', localConfig.userStats.balance + 10)} color="emerald" />
                  <OverrideButton label="+ ₹100.00" onClick={() => overrideUserStat('balance', localConfig.userStats.balance + 100)} color="emerald" />
                  <OverrideButton label="- ₹50.00" onClick={() => overrideUserStat('balance', Math.max(0, localConfig.userStats.balance - 50))} color="rose" />
                  <OverrideButton label="Clear" onClick={() => overrideUserStat('balance', 0)} color="slate" />
               </div>

               <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-500 uppercase ml-2">XP Level</label>
                    <input type="number" value={localConfig.userStats.xp} onChange={e => overrideUserStat('xp', parseInt(e.target.value))} className="w-full bg-slate-950 border border-white/5 rounded-2xl px-5 py-3 text-xs text-indigo-400 outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-500 uppercase ml-2">Active Streak</label>
                    <input type="number" value={localConfig.userStats.streak} onChange={e => overrideUserStat('streak', parseInt(e.target.value))} className="w-full bg-slate-950 border border-white/5 rounded-2xl px-5 py-3 text-xs text-indigo-400 outline-none" />
                  </div>
               </div>
            </div>
          </div>
        )}

        {activePanel === 'support' && (
          <div className="space-y-10 animate-fade-in">
            <header className="space-y-1">
              <h2 className="text-3xl font-black text-white tracking-tighter italic uppercase">Support_Desk</h2>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em]">Inquiry Management</p>
            </header>

            <div className="space-y-4">
              {localConfig.supportTickets.map(t => (
                <div key={t.id} className={`p-6 bg-slate-900 border border-white/5 rounded-3xl flex flex-col md:flex-row gap-6 ${t.status === 'resolved' ? 'opacity-30 grayscale' : 'shadow-xl'}`}>
                   <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                         <span className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">{t.user}</span>
                         <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${t.status === 'open' ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-400'}`}>{t.status}</span>
                      </div>
                      <h4 className="text-sm font-black text-white">{t.subject}</h4>
                      <p className="text-xs text-slate-400 line-clamp-2">{t.message}</p>
                   </div>
                   {t.status !== 'resolved' && (
                     <button onClick={() => resolveTicket(t.id)} className="px-6 py-3 bg-emerald-600 rounded-xl text-[9px] font-black text-white uppercase tracking-widest self-center">Resolve</button>
                   )}
                </div>
              ))}
            </div>
          </div>
        )}

        {activePanel === 'system' && (
          <div className="space-y-10 animate-fade-in">
            <header className="space-y-1">
              <h2 className="text-3xl font-black text-white tracking-tighter italic uppercase">System_Core</h2>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em]">Global Protocol Controls</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
               <AdminSection title="Core Flags" color="text-rose-400">
                  <ToggleRow label="Maintenance Mode" active={localConfig.system.maintenanceMode} onToggle={() => updateSystemSetting('maintenanceMode', !localConfig.system.maintenanceMode)} />
                  <ToggleRow label="Force Mandatory Update" active={localConfig.system.forceUpdate} onToggle={() => updateSystemSetting('forceUpdate', !localConfig.system.forceUpdate)} />
               </AdminSection>

               <AdminSection title="Versioning" color="text-amber-400">
                  <AdIdInput label="Target Build" value={localConfig.system.currentVersion} onChange={v => updateSystemSetting('currentVersion', v)} />
                  <AdIdInput label="Min Version" value={localConfig.system.minRequiredVersion} onChange={v => updateSystemSetting('minRequiredVersion', v)} />
                  <AdIdInput label="Update URL" value={localConfig.system.updateUrl} onChange={v => updateSystemSetting('updateUrl', v)} />
               </AdminSection>
            </div>
          </div>
        )}
      </main>

      {/* MOBILE BOTTOM NAV */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-white/5 p-4 flex justify-between z-50 overflow-x-auto scrollbar-hide">
         {panels.map(p => (
           <button 
             key={p.id}
             onClick={() => setActivePanel(p.id)} 
             className={`flex flex-col items-center gap-1 min-w-[60px] p-2 transition-all ${activePanel === p.id ? 'text-indigo-500 scale-110' : 'text-slate-600'}`}
           >
             <span className="text-xl">{p.icon}</span>
             <span className="text-[8px] font-black uppercase tracking-widest">{p.label}</span>
           </button>
         ))}
      </nav>
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 ${active ? 'bg-indigo-600 text-white shadow-xl font-black italic translate-x-1' : 'text-slate-500 hover:bg-white/5 hover:text-slate-300'}`}>
     <span className="text-xl">{icon}</span>
     <span className="text-[10px] uppercase tracking-widest">{label}</span>
  </button>
);

const AdminSection = ({ title, children, color }: any) => (
  <div className="bg-slate-900/50 border border-white/5 rounded-[40px] p-8 space-y-6 shadow-2xl">
     <h3 className={`text-[10px] font-black ${color} uppercase tracking-widest italic border-b border-white/5 pb-4`}>{title}</h3>
     <div className="space-y-4">{children}</div>
  </div>
);

const ToggleRow = ({ label, active, onToggle }: any) => (
  <div className="flex items-center justify-between p-4 bg-slate-950/50 rounded-2xl border border-white/5">
     <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{label}</span>
     <button onClick={onToggle} className={`w-12 h-6 rounded-full relative transition-all ${active ? 'bg-emerald-600 shadow-[0_0_10px_rgba(16,185,129,0.3)]' : 'bg-slate-800'}`}>
        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${active ? 'left-7' : 'left-1'}`}></div>
     </button>
  </div>
);

const AdIdInput = ({ label, value, onChange }: any) => (
  <div className="space-y-1">
    <label className="text-[8px] font-black text-slate-600 uppercase tracking-widest ml-4">{label}</label>
    <input type="text" value={value} onChange={e => onChange(e.target.value)} className="w-full bg-slate-950 border border-white/5 rounded-2xl px-5 py-3 text-[10px] font-mono text-indigo-300 outline-none" placeholder="..." />
  </div>
);

const OverrideButton = ({ label, onClick, color }: any) => (
  <button onClick={onClick} className={`p-3 bg-${color}-500/10 border border-${color}-500/20 rounded-xl text-${color}-500 font-black text-[9px] uppercase hover:bg-${color}-500/20 transition-all`}>
    {label}
  </button>
);

const StatCard = ({ label, value, prefix, suffix, color, pulse }: any) => (
  <div className="p-6 bg-slate-900 border border-white/5 rounded-[30px] shadow-lg relative overflow-hidden group">
     <div className="flex justify-between items-start mb-2">
        <div className="text-[8px] font-black uppercase text-slate-600 tracking-widest">{label}</div>
        {pulse && <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-ping"></div>}
     </div>
     <div className={`text-xl font-black italic tracking-tighter ${color}`}>{prefix}{value}{suffix}</div>
  </div>
);

export default AdminDashboard;
