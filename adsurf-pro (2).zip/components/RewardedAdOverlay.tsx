
import React, { useState, useEffect } from 'react';

interface RewardedAdOverlayProps {
  id: string;
  onComplete: () => void;
  onCancel: () => void;
}

const RewardedAdOverlay: React.FC<RewardedAdOverlayProps> = ({ id, onComplete, onCancel }) => {
  const [timeLeft, setTimeLeft] = useState(15);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setIsFinished(true);
    }
  }, [timeLeft]);

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950 flex flex-col animate-fade-in">
      {/* Ad Player Area */}
      <div className="flex-1 flex flex-col items-center justify-center bg-black relative">
        <div className="absolute top-6 left-6 right-6 flex items-center justify-between">
          <div className="bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/20 flex items-center gap-2">
            <div className="w-2 h-2 bg-rose-500 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-bold text-white uppercase tracking-widest">Watching Ad for Reward</span>
          </div>
          <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center font-black text-white">
            {timeLeft > 0 ? timeLeft : '✓'}
          </div>
        </div>

        <div className="text-center space-y-6 px-10">
           <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-[40px] shadow-2xl shadow-indigo-500/50 mx-auto flex items-center justify-center text-4xl animate-pulse">
             📦
           </div>
           <div className="space-y-2">
             <h2 className="text-3xl font-black text-white tracking-tight">Cloud Storage Pro</h2>
             <p className="text-slate-400 text-sm">Save your data securely with military-grade encryption.</p>
           </div>
           <button className="bg-white text-slate-950 px-10 py-4 rounded-2xl font-black shadow-2xl hover:scale-105 active:scale-95 transition-all">
             GET PREMIUM FREE
           </button>
        </div>
      </div>

      {/* Reward Status Area */}
      <div className="p-8 bg-slate-900 border-t border-slate-800 space-y-4">
        <div className="flex items-center justify-between mb-2">
           <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Your Progress</span>
           <span className="text-amber-500 font-bold text-xs uppercase">Reward: 10m Ad-Free</span>
        </div>
        <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
           <div 
             className="h-full bg-amber-500 transition-all duration-1000 ease-linear" 
             style={{ width: `${((15 - timeLeft) / 15) * 100}%` }} 
           />
        </div>
        <div className="flex gap-4 pt-2">
           <button 
             onClick={onCancel}
             className="flex-1 py-4 text-slate-500 font-bold text-sm hover:text-white transition-colors"
           >
             No Thanks
           </button>
           <button 
             onClick={isFinished ? onComplete : undefined}
             disabled={!isFinished}
             className={`flex-1 py-4 rounded-2xl font-black transition-all ${isFinished ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'bg-slate-800 text-slate-600 cursor-not-allowed'}`}
           >
             Claim Reward
           </button>
        </div>
      </div>

      <div className="absolute top-4 left-4 pointer-events-none">
        <span className="text-[8px] font-mono text-white/30">RID: {id.slice(-8)}</span>
      </div>
    </div>
  );
};

export default RewardedAdOverlay;
