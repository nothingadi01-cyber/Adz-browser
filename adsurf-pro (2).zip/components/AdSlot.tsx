
import React, { useState, useEffect, useRef } from 'react';

interface AdSlotProps {
  type: 'banner' | 'native' | 'in-post' | 'video' | 'app-grid' | 'large-rect' | 'app-open' | 'rewarded-interstitial';
  interval: number;
  adUnitId: string;
  source?: 'admob' | 'adsense' | 'custom';
  isPaused?: boolean;
}

const AdSlot: React.FC<AdSlotProps> = ({ type, interval, adUnitId, source = 'admob', isPaused = false }) => {
  const [refreshCount, setRefreshCount] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [timeToRefresh, setTimeToRefresh] = useState(interval);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    if (isPaused) return;
    setTimeToRefresh(interval);

    timerRef.current = setInterval(() => {
      setIsRefreshing(true);
      setTimeout(() => {
        setRefreshCount(c => c + 1);
        setIsRefreshing(false);
        setTimeToRefresh(interval);
      }, 900);
    }, interval * 1000);

    const progressTimer = setInterval(() => {
      setTimeToRefresh(prev => Math.max(0, prev - 1));
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      clearInterval(progressTimer);
    };
  }, [interval, isPaused]);

  const renderContent = () => {
    if (isRefreshing) {
      return (
        <div className="absolute inset-0 bg-slate-900/90 flex flex-col items-center justify-center backdrop-blur-md z-20">
          <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-[7px] font-black text-indigo-400 uppercase tracking-widest mt-2">Updating_Revenue_Node</span>
        </div>
      );
    }

    const AdBadge = () => (
      <div className="flex items-center gap-2">
         <span className="bg-slate-950 px-2 py-0.5 rounded text-[7px] font-mono text-slate-500 border border-white/5 uppercase">ID: {adUnitId.slice(-8)}</span>
         <span className="text-[7px] font-black text-indigo-500 uppercase tracking-widest">{timeToRefresh}s</span>
      </div>
    );

    switch (type) {
      case 'banner':
        return (
          <div className="w-full h-full bg-slate-900/40 flex items-center justify-between px-8 border-y border-white/5 relative overflow-hidden group cursor-pointer">
             <div className="flex items-center gap-4">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-[10px] font-black text-white shadow-lg shadow-indigo-600/20">AD</div>
                <div className="flex flex-col">
                   <span className="text-[11px] font-black text-white truncate w-40 italic">Premium Sponsor Unit</span>
                   <AdBadge />
                </div>
             </div>
             <button className="bg-white text-slate-950 text-[9px] font-black px-5 py-2.5 rounded-xl uppercase tracking-tighter shadow-xl">Open</button>
          </div>
        );

      case 'large-rect':
        return (
          <div className="bg-slate-900/80 rounded-[50px] border border-white/5 overflow-hidden shadow-2xl min-h-[300px] flex flex-col group cursor-pointer relative">
             <div className="h-44 bg-slate-950 flex items-center justify-center relative">
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 via-transparent to-purple-500/10 opacity-60"></div>
                <div className="text-6xl group-hover:scale-110 transition-transform duration-[2s]">💎</div>
                <div className="absolute top-6 right-6">
                   <AdBadge />
                </div>
             </div>
             <div className="p-10 space-y-6 flex-1 flex flex-col justify-between">
                <div>
                   <h4 className="text-2xl font-black text-white italic tracking-tighter leading-none">Elite Network Offer</h4>
                   <p className="text-[11px] text-slate-500 font-bold uppercase tracking-widest mt-2">Claim your priority yield reward now.</p>
                </div>
                <button className="w-full py-5 rounded-[25px] bg-indigo-600 text-white text-[11px] font-black uppercase tracking-widest shadow-xl shadow-indigo-600/30">Activate Node</button>
             </div>
          </div>
        );

      case 'in-post':
        return (
          <div className="bg-slate-900/60 border border-white/10 rounded-[40px] p-8 space-y-6 shadow-2xl group relative overflow-hidden">
             <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-slate-950 rounded-2xl flex items-center justify-center text-3xl border border-white/5 shadow-inner">⚡</div>
                   <div className="flex flex-col">
                      <span className="text-sm font-black text-white italic">Node Accelerator</span>
                      <AdBadge />
                   </div>
                </div>
                <button className="bg-white/5 border border-white/10 text-slate-400 px-4 py-2 rounded-xl text-[9px] font-black uppercase">Install</button>
             </div>
             <div className="h-1 w-full bg-slate-950 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-600 transition-all duration-1000 ease-linear" style={{ width: `${(timeToRefresh / interval) * 100}%` }}></div>
             </div>
          </div>
        );

      default:
        return (
          <div className="bg-slate-900/30 rounded-[40px] border border-white/5 p-8 flex items-center justify-center text-center animate-fade-in group cursor-pointer overflow-hidden relative">
             <div className="space-y-4 relative z-10">
                <div className="text-4xl group-hover:rotate-12 transition-transform">🛰️</div>
                <div className="flex flex-col items-center gap-1">
                   <span className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em]">Monetization Protocol Active</span>
                   <AdBadge />
                </div>
             </div>
          </div>
        );
    }
  };

  return (
    <div className={`relative overflow-hidden transition-all duration-500 ${type === 'banner' ? 'h-[65px]' : 'p-3'}`}>
      {renderContent()}
    </div>
  );
};

export default AdSlot;
