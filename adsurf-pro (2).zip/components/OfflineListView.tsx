
import React from 'react';
import { OfflineItem } from '../types/config';

interface OfflineListViewProps {
  items: OfflineItem[];
  onNavigate: (url: string) => void;
  onClose: () => void;
}

const OfflineListView: React.FC<OfflineListViewProps> = ({ items, onNavigate, onClose }) => {
  return (
    <div className="absolute inset-0 z-50 bg-slate-950 flex flex-col animate-fade-in">
      <header className="p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 text-slate-400">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
          </button>
          <h3 className="text-lg font-bold">Offline Library</h3>
        </div>
        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
          Local Cache
        </span>
      </header>

      <div className="flex-1 overflow-auto">
        {items.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center p-12 text-center text-slate-500 space-y-4">
             <div className="text-5xl opacity-50 grayscale">📦</div>
             <div>
               <p className="font-bold text-slate-300">No cached pages</p>
               <p className="text-xs max-w-[200px] mt-2 leading-relaxed">Save pages from the menu to read them later without an internet connection.</p>
             </div>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/50">
            {items.map(item => (
              <div 
                key={item.id} 
                onClick={() => { onNavigate(item.url); onClose(); }}
                className="p-5 flex gap-4 hover:bg-slate-900 transition-colors cursor-pointer group"
              >
                 <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center font-black text-indigo-500 border border-slate-800 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    {item.title[0]}
                 </div>
                 <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-slate-200 truncate">{item.title}</div>
                    <div className="text-[10px] text-slate-500 truncate mt-0.5">{item.url}</div>
                    <div className="flex items-center gap-2 mt-2">
                       <span className="text-[9px] font-bold text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 uppercase tracking-tighter">Ready Offline</span>
                       <span className="text-[9px] text-slate-600">{new Date(item.timestamp).toLocaleDateString()}</span>
                    </div>
                 </div>
                 <div className="self-center">
                    <svg className="w-5 h-5 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                 </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      <footer className="p-6 bg-slate-900/50 border-t border-slate-800 text-[10px] text-center text-slate-500 font-medium">
         Local storage automatically manages cache to optimize performance.
      </footer>
    </div>
  );
};

export default OfflineListView;
