
import React from 'react';
import { CurrencyCode } from '../types/config';

interface MenuOverlayProps {
  isDesktop: boolean;
  isDarkMode: boolean;
  isPerformanceMode: boolean;
  isAdBlockerActive: boolean;
  currency: CurrencyCode;
  onToggleDesktop: () => void;
  onToggleTheme: () => void;
  onTogglePerformance: () => void;
  onToggleAdBlocker: () => void;
  onToggleCurrency: () => void;
  onNewTab: (incognito?: boolean) => void;
  onOpenDownloads: () => void;
  onOpenHistory: () => void;
  onOpenBookmarks: () => void;
  onOpenOffline: () => void;
  onAddBookmark: () => void;
  onSaveOffline: () => void;
  onExitApp: () => void;
  onClose: () => void;
}

const MenuOverlay: React.FC<MenuOverlayProps> = ({ 
  isDesktop, isDarkMode, isPerformanceMode, isAdBlockerActive, currency,
  onToggleDesktop, onToggleTheme, onTogglePerformance, onToggleAdBlocker, onToggleCurrency,
  onNewTab, onOpenDownloads, onOpenHistory, onOpenBookmarks, onOpenOffline,
  onAddBookmark, onSaveOffline, onExitApp, onClose 
}) => {
  return (
    <div className="absolute inset-0 z-[500] animate-fade-in">
      <div className="absolute inset-0 bg-[#020617]/80 backdrop-blur-3xl" onClick={onClose} />
      <div className="absolute bottom-0 left-0 right-0 bg-slate-900 border-t border-white/5 rounded-t-[70px] p-12 space-y-12 shadow-[0_-50px_100px_rgba(0,0,0,0.9)]">
        <div className="w-16 h-1.5 bg-slate-800 rounded-full mx-auto mb-4" />
        
        <div className="grid grid-cols-4 gap-10">
          <MenuButton icon="📑" label="New Tab" onClick={() => onNewTab(false)} />
          <MenuButton icon="🕶️" label="Incognito" onClick={() => onNewTab(true)} />
          <MenuButton icon="🕒" label="History" onClick={onOpenHistory} />
          <MenuButton icon="📁" label="Bookmarks" onClick={onOpenBookmarks} />
          <MenuButton icon="🖥️" label="Desktop" active={isDesktop} onClick={onToggleDesktop} />
          <MenuButton icon={isDarkMode ? '🌙' : '☀️'} label="Theme" onClick={onToggleTheme} />
          <MenuButton icon="⚡" label="Lite" active={isPerformanceMode} onClick={onTogglePerformance} />
          <MenuButton icon="🚪" label="Exit" onClick={onExitApp} />
        </div>

        <div className="bg-slate-950/80 rounded-[40px] p-8 flex items-center justify-between border border-white/5 shadow-inner">
          <div className="flex items-center gap-5">
             <div className={`w-14 h-14 rounded-[22px] flex items-center justify-center text-3xl transition-all shadow-xl ${isAdBlockerActive ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-500'}`}>
                {isAdBlockerActive ? '🛡️' : '🔓'}
             </div>
             <div>
               <div className="text-md font-black text-white italic uppercase tracking-tighter">Ad_Blocker</div>
               <div className="text-[10px] text-slate-600 font-black uppercase tracking-widest">{isAdBlockerActive ? 'Node Shield Active' : 'Passive Monitoring'}</div>
             </div>
          </div>
          <button 
            onClick={onToggleAdBlocker}
            className={`w-16 h-9 rounded-full relative transition-all shadow-inner ${isAdBlockerActive ? 'bg-emerald-600' : 'bg-slate-800'}`}
          >
             <div className={`absolute top-1.5 w-6 h-6 bg-white rounded-full transition-all shadow-md ${isAdBlockerActive ? 'left-9' : 'left-1.5'}`} />
          </button>
        </div>
      </div>
    </div>
  );
};

const MenuButton: React.FC<{ icon: string, label: string, active?: boolean, onClick?: () => void }> = ({ icon, label, active, onClick }) => (
  <button onClick={onClick} className="flex flex-col items-center gap-4 group">
    <div className={`w-18 h-18 rounded-[30px] flex items-center justify-center text-4xl transition-all duration-300 shadow-2xl ${active ? 'bg-indigo-600 shadow-indigo-600/40 scale-110 rotate-3' : 'bg-slate-800 hover:bg-indigo-900/40 hover:scale-105 active:scale-90 border border-white/5'}`}>
      {icon}
    </div>
    <span className={`text-[10px] font-black uppercase tracking-[0.3em] text-center leading-tight italic ${active ? 'text-indigo-400' : 'text-slate-600 group-hover:text-slate-300'}`}>{label}</span>
  </button>
);

export default MenuOverlay;
