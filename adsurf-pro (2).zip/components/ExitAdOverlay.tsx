
import React from 'react';

interface ExitAdOverlayProps {
  onStay: () => void;
  onExit: () => void;
}

const ExitAdOverlay: React.FC<ExitAdOverlayProps> = ({ onStay, onExit }) => {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 animate-fade-in">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={onStay} />
      
      <div className="bg-slate-900 w-full max-w-sm rounded-[40px] border border-slate-800 overflow-hidden shadow-2xl relative z-10">
        <div className="p-8 space-y-6">
          <div className="flex items-center justify-between">
             <div className="bg-rose-500/10 text-rose-500 text-[10px] font-bold px-3 py-1 rounded-full border border-rose-500/20 uppercase tracking-widest">Wait! Don't Go</div>
             <button onClick={onStay} className="text-slate-500 hover:text-white transition-colors">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
             </button>
          </div>
          
          <div className="space-y-3">
             <h3 className="text-2xl font-black text-white leading-tight">Before you leave...</h3>
             <p className="text-slate-400 text-sm leading-relaxed">Check out this special browser extension to speed up your web experience by 2x.</p>
          </div>

          <div className="bg-slate-950 rounded-3xl p-6 border border-slate-800 space-y-4">
             <div className="flex items-center gap-4">
               <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-2xl">⚡</div>
               <div>
                  <div className="text-sm font-bold text-white uppercase tracking-tighter">SuperTurbo Pro</div>
                  <div className="text-[10px] text-slate-500">4.9/5 Rating (12k Users)</div>
               </div>
             </div>
             <button className="w-full bg-white text-slate-950 py-3 rounded-xl font-black text-sm hover:bg-slate-100 transition-all">
               Install & Continue
             </button>
          </div>

          <div className="flex flex-col gap-2 pt-2">
             <button onClick={onStay} className="w-full py-4 bg-slate-800 hover:bg-slate-700 rounded-2xl font-bold text-sm text-slate-200 transition-all">
               Stay in Browser
             </button>
             <button onClick={onExit} className="w-full py-3 text-slate-600 font-bold text-[10px] uppercase tracking-widest hover:text-rose-400 transition-colors">
               Exit Anyway
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExitAdOverlay;
