
import React, { useState, useEffect } from 'react';
import { NewsItem } from '../types/config';
import AdSlot from './AdSlot';
import { GoogleGenAI } from "@google/genai";

interface NewsFeedProps {
  news: NewsItem[];
  customArticles: NewsItem[];
  isLoading: boolean;
  onOpenArticle: (item: NewsItem) => void;
  adInterval: number;
  onRefresh: (category: string) => void;
  // Added to fix missing property errors in AdSlot components
  adUnitId: string;
}

const NewsFeed: React.FC<NewsFeedProps> = ({ news, customArticles, isLoading, onOpenArticle, adInterval, onRefresh, adUnitId }) => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [summaries, setSummaries] = useState<Record<string, string>>({});
  const [isSummarizing, setIsSummarizing] = useState<string | null>(null);

  const categories = ['All', 'Technology', 'Business', 'Science', 'Sports', 'Health', 'Entertainment'];

  const handleCategoryChange = (cat: string) => {
    setActiveCategory(cat);
    onRefresh(cat);
  };

  const summarizeArticle = async (e: React.MouseEvent, item: NewsItem) => {
    e.stopPropagation();
    if (summaries[item.id]) return;
    setIsSummarizing(item.id);
    
    // Correct usage of GoogleGenAI as per guidelines
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Summarize this news article into 3 punchy, informative bullet points. 
        Focus on the 'who, what, and why'. 
        Title: ${item.title}. 
        Content: ${item.content || item.title}`,
        config: { temperature: 0.7 }
      });
      // Correct property access for .text
      setSummaries(prev => ({ ...prev, [item.id]: response.text || 'Summary unavailable' }));
    } catch (err) {
      console.error(err);
      setSummaries(prev => ({ ...prev, [item.id]: 'AI Recap temporarily unavailable.' }));
    } finally {
      setIsSummarizing(null);
    }
  };

  const renderArticle = (item: NewsItem, idx: number) => (
    <React.Fragment key={item.id}>
      <div 
        onClick={() => onOpenArticle(item)}
        className="bg-slate-900/40 rounded-[28px] border border-white/5 overflow-hidden group hover:border-indigo-500/30 transition-all duration-300 flex flex-col shadow-xl cursor-pointer"
      >
        <div className="p-6 space-y-4">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl shadow-inner border border-white/5 group-hover:bg-indigo-600 transition-colors ${item.isCustom ? 'bg-indigo-600/20 text-indigo-400' : 'bg-slate-800'}`}>
                {item.isCustom ? '⭐' : '📰'}
              </div>
              <div className="min-w-0">
                <div className="text-[10px] font-black text-indigo-400 uppercase truncate max-w-[150px]">{item.source}</div>
                <div className="text-[10px] text-slate-500 font-bold uppercase">{item.time}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
               {item.isCustom && (
                 <span className="bg-indigo-600 text-[8px] font-black text-white px-2 py-0.5 rounded uppercase tracking-widest">Featured</span>
               )}
               <button 
                 onClick={(e) => summarizeArticle(e, item)}
                 disabled={isSummarizing === item.id}
                 className="glass text-indigo-400 px-3 py-1.5 rounded-xl border border-indigo-500/20 hover:bg-indigo-600 hover:text-white transition-all text-[9px] font-black uppercase flex items-center gap-2 shrink-0"
               >
                 {isSummarizing === item.id ? (
                   <div className="w-3 h-3 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
                 ) : (
                   <span className="flex items-center gap-1">✨ AI Recap</span>
                 )}
               </button>
            </div>
          </div>
          
          <h3 className="text-lg font-black text-white leading-tight group-hover:text-indigo-300 transition-colors">
            {item.title}
          </h3>

          {summaries[item.id] && (
            <div className="bg-slate-950/80 rounded-2xl p-4 border border-indigo-500/20 space-y-2 animate-fade-in shadow-inner">
              <div className="text-[9px] font-black text-indigo-500 uppercase tracking-widest flex items-center gap-2">
                 <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse"></span>
                 Key Insights
              </div>
              <div className="text-[11px] text-slate-300 leading-relaxed font-semibold">
                {summaries[item.id].split('\n').map((line, i) => (
                  line.trim() && <div key={i} className="flex gap-2 mb-1 last:mb-0"><span className="text-indigo-500">•</span>{line.replace(/^[*-]\s?/, '')}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Strategic Ad Injection - Passing required adUnitId */}
      {(idx + 1) % 3 === 0 && (
        <div className="py-2 animate-scale-in">
          {idx % 12 === 2 && <AdSlot type="in-post" interval={adInterval} adUnitId={adUnitId} />}
          {idx % 12 === 5 && <AdSlot type="video" interval={adInterval} adUnitId={adUnitId} />}
          {idx % 12 === 8 && <AdSlot type="large-rect" interval={adInterval} adUnitId={adUnitId} />}
          {idx % 12 === 11 && <AdSlot type="app-open" interval={adInterval} adUnitId={adUnitId} />}
        </div>
      )}
    </React.Fragment>
  );

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-auto scrollbar-hide animate-fade-in">
      <div className="sticky top-0 z-20 glass px-4 py-4 flex items-center overflow-x-auto scrollbar-hide">
        <div className="flex gap-2.5 px-2">
          {categories.map(cat => (
            <button 
              key={cat}
              onClick={() => handleCategoryChange(cat)}
              className={`px-5 py-2 rounded-[14px] text-[11px] font-black transition-all whitespace-nowrap border ${
                activeCategory === cat 
                  ? 'bg-indigo-600 text-white border-indigo-500 shadow-xl shadow-indigo-600/30' 
                  : 'bg-white/5 text-slate-400 border-white/5 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat === 'Technology' ? 'Tech' : cat === 'Business' ? 'Finance' : cat}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 space-y-8 pb-32">
        <div className="rounded-[24px] overflow-hidden border border-slate-800 shadow-xl">
           <AdSlot type="banner" interval={adInterval} adUnitId={adUnitId} />
        </div>

        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-slate-900/40 rounded-[28px] border border-white/5 p-6 space-y-4 animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-800"></div>
                  <div className="space-y-2">
                    <div className="h-2 w-20 bg-slate-800 rounded"></div>
                    <div className="h-2 w-12 bg-slate-800 rounded"></div>
                  </div>
                </div>
                <div className="h-4 w-full bg-slate-800 rounded"></div>
                <div className="h-4 w-2/3 bg-slate-800 rounded"></div>
              </div>
            ))}
          </div>
        ) : news.length === 0 && customArticles.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-4xl mb-4">📭</div>
            <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px]">No news available</p>
            <button onClick={() => handleCategoryChange(activeCategory)} className="mt-4 bg-indigo-600 px-6 py-2 rounded-xl text-[10px] font-black uppercase shadow-lg shadow-indigo-600/20">Refresh Feed</button>
          </div>
        ) : (
          <>
            {/* AGGREGATED NEWS SECTION */}
            {news.map((item, idx) => renderArticle(item, idx))}

            {/* CUSTOM ARTICLES SECTION */}
            {customArticles.length > 0 && (
              <div className="pt-8 space-y-8">
                 <div className="flex items-center gap-4">
                    <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-indigo-500/30"></div>
                    <span className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.4em] whitespace-nowrap">Featured Editorial</span>
                    <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-indigo-500/30"></div>
                 </div>
                 {customArticles.map((item, idx) => renderArticle(item, news.length + idx))}
              </div>
            )}
          </>
        )}

        <div className="pt-8 text-center pb-20 border-t border-slate-900">
          <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest">End of Intelligence Feed</p>
          <div className="w-1 h-1 bg-slate-800 rounded-full mx-auto mt-4"></div>
        </div>
      </div>
    </div>
  );
};

export default NewsFeed;
