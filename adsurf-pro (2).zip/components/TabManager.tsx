
import React from 'react';
import { BrowserTab } from '../types/config';

interface TabManagerProps {
  tabs: BrowserTab[];
  activeTabId: string;
  onSwitch: (id: string) => void;
  onCloseTab: (id: string) => void;
  onNewTab: () => void;
  onClose: () => void;
}

const TabManager: React.FC<TabManagerProps> = ({ tabs, activeTabId, onSwitch, onCloseTab, onNewTab, onClose }) => {
  return (
    <div className="absolute inset-0 z-50 bg-slate-950 flex flex-col animate-fade-in">
      <header className="p-4 border-b border-slate-800 flex items-center justify-between">
        <h3 className="text-lg font-bold">Tabs ({tabs.length})</h3>
        <button onClick={onClose} className="p-2 text-slate-400">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
      </header>
      
      <div className="flex-1 overflow-auto p-4">
        <div className="grid grid-cols-2 gap-4">
          {tabs.map(tab => (
            <div 
              key={tab.id}
              onClick={() => { onSwitch(tab.id); onClose(); }}
              className={`relative aspect-[3/4] rounded-2xl border-2 overflow-hidden group cursor-pointer transition-all ${tab.id === activeTabId ? 'border-indigo-600 ring-2 ring-indigo-600/20' : 'border-slate-800'}`}
            >
              <div className={`h-full w-full p-4 flex flex-col ${tab.isIncognito ? 'bg-slate-900' : 'bg-slate-800/50'}`}>
                <div className="flex items-center justify-between mb-2">
                   <span className="text-[10px] font-bold truncate max-w-[80%]">{tab.title}</span>
                   <button 
                     onClick={(e) => { e.stopPropagation(); onCloseTab(tab.id); }}
                     className="p-1 rounded-full bg-slate-950/50 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400"
                   >
                     <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                   </button>
                </div>
                <div className="flex-1 bg-slate-950/30 rounded-lg flex items-center justify-center text-slate-700">
                  <span className="text-[10px] truncate px-2">{tab.url}</span>
                </div>
              </div>
              {tab.isIncognito && (
                <div className="absolute top-2 left-2 w-4 h-4 text-purple-400">
                  <svg fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a1 1 0 00-1 1v1a1 1 0 002 0V3a1 1 0 00-1-1zM4 4h3a3 3 0 006 0h3a2 2 0 012 2v9a2 2 0 01-2 2H4a2 2 0 01-2 2V6a2 2 0 012-2zm10 4a2 2 0 11-4 0 2 2 0 014 0zM7 8a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                </div>
              )}
            </div>
          ))}
          <button 
            onClick={onNewTab}
            className="aspect-[3/4] rounded-2xl border-2 border-dashed border-slate-800 flex flex-col items-center justify-center gap-2 text-slate-500 hover:border-indigo-500 hover:text-indigo-400 transition-all"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
            <span className="text-xs font-bold">New Tab</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default TabManager;
