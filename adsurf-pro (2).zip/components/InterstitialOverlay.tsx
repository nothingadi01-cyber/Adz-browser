
import React, { useState, useEffect } from 'react';

interface InterstitialOverlayProps {
  id: string;
  onClose: () => void;
}

const InterstitialOverlay: React.FC<InterstitialOverlayProps> = ({ id, onClose }) => {
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  return (
    <div className="absolute inset-0 z-50 bg-slate-950 flex flex-col animate-fade-in">
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-6">
        <div className="w-24 h-24 bg-indigo-600 rounded-3xl shadow-2xl shadow-indigo-600/40 flex items-center justify-center animate-bounce">
          <span className="text-4xl">🚀</span>
        </div>
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Super Speed VPN</h2>
          <p className="text-slate-400 max-w-xs mx-auto">Enhance your browsing speed and protect your privacy with one tap.</p>
        </div>
        <div className="grid grid-cols-2 gap-4 w-full">
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
             <span className="block text-2xl font-bold text-emerald-400">99.9%</span>
             <span className="text-[10px] text-slate-500 uppercase tracking-widest">Uptime</span>
          </div>
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
             <span className="block text-2xl font-bold text-blue-400">50+</span>
             <span className="text-[10px] text-slate-500 uppercase tracking-widest">Servers</span>
          </div>
        </div>
      </div>
      
      <div className="p-8 space-y-3">
        <button className="w-full bg-white text-slate-950 py-4 rounded-2xl font-bold text-lg hover:bg-slate-200 transition-colors">
          Download App
        </button>
        <button 
          onClick={countdown === 0 ? onClose : undefined}
          className={`w-full py-4 text-slate-500 text-sm font-medium transition-all ${countdown === 0 ? 'text-slate-300 hover:text-white cursor-pointer' : 'opacity-50 cursor-not-allowed'}`}
        >
          {countdown > 0 ? `Skip in ${countdown}s` : 'Skip Ad'}
        </button>
      </div>

      <div className="absolute top-4 left-4">
        <span className="bg-slate-900/80 px-2 py-1 rounded text-[10px] border border-slate-800 text-slate-500">Ad: {id.slice(0, 10)}...</span>
      </div>
    </div>
  );
};

export default InterstitialOverlay;
