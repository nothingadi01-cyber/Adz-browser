
import React, { useEffect, useState } from 'react';
import { BrowserConfig } from '../types/config';

interface SplashScreenAdProps {
  config: BrowserConfig;
  onFinish: () => void;
}

const SplashScreenAd: React.FC<SplashScreenAdProps> = ({ config, onFinish }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const duration = 4000; // 4 seconds
    const interval = 40;
    const step = (interval / duration) * 100;

    const timer = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(timer);
          setTimeout(onFinish, 200);
          return 100;
        }
        return p + step;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-[1000] bg-slate-950 flex flex-col items-center justify-between p-12 text-center animate-fade-in">
      <div className="pt-20 space-y-4">
        <div className={`w-24 h-24 rounded-3xl bg-${config.themeColor}-600 mx-auto flex items-center justify-center text-4xl font-bold text-white shadow-2xl shadow-${config.themeColor}-600/40 animate-bounce`}>
          {config.appName[0]}
        </div>
        <h1 className="text-3xl font-black tracking-tighter text-white">{config.appName}</h1>
      </div>

      <div className="w-full max-w-xs space-y-8">
        {/* Splash Ad Placement */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-4 animate-pulse">
           <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-indigo-600 rounded-lg"></div>
             <div className="text-left">
               <div className="h-3 w-32 bg-slate-800 rounded-full mb-2"></div>
               <div className="h-2 w-20 bg-slate-800 rounded-full"></div>
             </div>
           </div>
           <div className="h-32 bg-slate-950 rounded-xl flex items-center justify-center text-[10px] text-slate-700 font-mono">
             SPLASH_PLACEMENT_PREMIUM
           </div>
        </div>

        <div className="space-y-4">
          <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
            <div 
              className={`h-full bg-${config.themeColor}-600 transition-all duration-75`} 
              style={{ width: `${progress}%` }} 
            />
          </div>
          <p className="text-[10px] font-bold text-slate-600 uppercase tracking-[0.2em]">Initializing Browser Engine...</p>
        </div>
      </div>
      
      <div className="pb-10">
        <p className="text-[10px] text-slate-500 font-medium">© 2025 {config.appName} Pro • Version 3.1.0</p>
      </div>
    </div>
  );
};

export default SplashScreenAd;
