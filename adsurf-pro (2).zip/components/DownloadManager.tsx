
import React from 'react';
import { DownloadItem } from '../types/config';

interface DownloadManagerProps {
  items: DownloadItem[];
  onClose: () => void;
}

const DownloadManager: React.FC<DownloadManagerProps> = ({ items, onClose }) => {
  return (
    <div className="absolute inset-0 z-50 bg-slate-950 flex flex-col animate-fade-in">
      <header className="p-4 border-b border-slate-800 flex items-center gap-4">
        <button onClick={onClose} className="p-2 text-slate-400">
           <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
        </button>
        <h3 className="text-lg font-bold">Downloads</h3>
      </header>

      <div className="flex-1 overflow-auto">
        {items.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
            <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center text-3xl">📥</div>
            <div>
              <p className="text-slate-300 font-bold">No Downloads Found</p>
              <p className="text-sm text-slate-500">Your downloaded files will appear here.</p>
            </div>
          </div>
        ) : (
          <div className="p-4 space-y-4">
            {items.map(item => (
              <div key={item.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-800 rounded-xl flex items-center justify-center text-xl">📄</div>
                <div className="flex-1">
                  <div className="text-sm font-bold truncate">{item.name}</div>
                  <div className="text-[10px] text-slate-500">{item.size} • {new Date(item.timestamp).toLocaleDateString()}</div>
                  {item.status === 'downloading' && (
                    <div className="mt-2 h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500" style={{ width: `${item.progress}%` }} />
                    </div>
                  )}
                </div>
                <button className="p-2 text-slate-500">
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" /></svg>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default DownloadManager;
