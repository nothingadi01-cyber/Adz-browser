
import React from 'react';
import { HistoryItem } from '../types/config';

interface HistoryViewProps {
  items: HistoryItem[];
  onNavigate: (url: string) => void;
  onClose: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ items, onNavigate, onClose }) => {
  const clusterItems = () => {
    const clusters: Record<string, HistoryItem[]> = {
      'Today': [],
      'Yesterday': [],
      'Older': []
    };

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const yesterday = today - 86400000;

    items.forEach(item => {
      if (item.timestamp >= today) clusters['Today'].push(item);
      else if (item.timestamp >= yesterday) clusters['Yesterday'].push(item);
      else clusters['Older'].push(item);
    });

    return clusters;
  };

  const clusters = clusterItems();

  return (
    <div className="absolute inset-0 z-[100] bg-slate-950 flex flex-col animate-fade-in">
      <header className="p-6 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white transition-colors">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" /></svg>
          </button>
          <h3 className="text-xl font-black text-white italic tracking-tighter">SURF_LOGS</h3>
        </div>
        <button className="text-[10px] font-black text-rose-500 uppercase tracking-widest px-4 py-2 bg-rose-500/10 rounded-xl border border-rose-500/20">Purge</button>
      </header>

      <div className="flex-1 overflow-auto p-6 space-y-10 scrollbar-hide">
        {items.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center p-8 text-center text-slate-500 space-y-4">
             <div className="text-6xl grayscale opacity-30">🕒</div>
             <p className="font-black uppercase tracking-[0.3em] text-xs">Clean Slate</p>
          </div>
        ) : (
          Object.entries(clusters).map(([title, cluster]) => cluster.length > 0 && (
            <div key={title} className="space-y-4">
               <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.4em] px-2">{title}</h4>
               <div className="space-y-2">
                 {cluster.map(item => (
                   <div 
                     key={item.id} 
                     onClick={() => { onNavigate(item.url); onClose(); }}
                     className="p-5 flex gap-4 bg-slate-900/40 rounded-[28px] border border-white/5 hover:bg-indigo-600/10 hover:border-indigo-500/20 transition-all cursor-pointer group"
                   >
                      <div className="w-10 h-10 bg-slate-950 rounded-xl flex items-center justify-center font-black text-slate-500 border border-slate-800 group-hover:scale-110 transition-transform">
                         {item.title[0]?.toUpperCase() || 'W'}
                      </div>
                      <div className="flex-1 min-w-0">
                         <div className="text-xs font-black text-white truncate">{item.title}</div>
                         <div className="text-[9px] text-slate-500 truncate mt-0.5">{item.url}</div>
                      </div>
                      <div className="text-[9px] text-slate-600 self-center font-bold">
                         {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                   </div>
                 ))}
               </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default HistoryView;
