
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';

// Global error logger for debugging deployment issues
window.onerror = (message, source, lineno, colno, error) => {
  console.error("CRITICAL_ERR:", message, "at", source, lineno, colno, error);
  const root = document.getElementById('root');
  if (root && root.innerHTML === '') {
    root.innerHTML = `<div style="padding: 20px; color: #f87171; font-family: monospace;">
      <h3>Deployment Error</h3>
      <p>${message}</p>
      <small>Check browser console for full trace.</small>
    </div>`;
  }
};

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Target container 'root' not found in document.");
}

try {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} catch (err) {
  console.error("MOUNT_FAIL:", err);
}
