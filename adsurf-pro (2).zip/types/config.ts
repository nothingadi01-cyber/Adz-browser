
export interface AdSettings {
  bannersEnabled: boolean;
  interstitialsEnabled: boolean;
  nativeAdsEnabled: boolean;
  splashEnabled: boolean;
  rewardedEnabled: boolean;
  exitAdsEnabled: boolean;
  appOpenEnabled: boolean;
  rewardedInterstitialEnabled: boolean;
  refreshInterval: number;
  inactivityTimeout: number;
  adSource: 'admob' | 'adsense' | 'custom';
  adMobId: string;
  bannerId: string;
  interstitialId: string;
  rewardedId: string;
  nativeId: string;
  nativeArticleId: string;
  inFeedNativeId: string;
  appOpenId: string;
  rewardedInterstitialId: string;
  homeTopId: string;
  stickyBannerId: string;
  exitAdProbability: number;
}

export interface InternalAd {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  actionUrl: string;
  type: 'banner' | 'native' | 'popup';
  active: boolean;
}

export interface NewsItem {
  id: string;
  title: string;
  source: string;
  time: string;
  category: string;
  imageUrl: string;
  content: string;
  isCustom?: boolean;
}

export interface MemeItem {
  id: string;
  title: string;
  imageUrl: string;
  likes: number;
  timestamp: number;
}

export interface SystemMessage {
  id: string;
  title: string;
  body: string;
  timestamp: number;
  type: 'info' | 'promo' | 'urgent';
  isRead: boolean;
}

export interface SupportTicket {
  id: string;
  user: string;
  subject: string;
  message: string;
  status: 'open' | 'pending' | 'resolved';
  timestamp: number;
}

export interface Transaction {
  id: string;
  type: 'search' | 'read' | 'ad' | 'referral' | 'checkin' | 'mission' | 'meme';
  amount: number;
  timestamp: number;
  label: string;
}

export interface HistoryItem {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface Bookmark {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface DownloadItem {
  id: string;
  name: string;
  size: string;
  timestamp: number;
  status: 'downloading' | 'completed' | 'failed';
  progress: number;
}

export interface OfflineItem {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface UserStats {
  balance: number;
  xp: number;
  level: number;
  adsWatched: number;
  articlesRead: number;
  searchesPerformed: number;
  lastCheckIn?: number;
  streak: number;
  multiplier: number;
  missionProgress: Record<string, number>;
  referralCode: string;
  referralsJoined: number;
  history: Transaction[];
  historyItems: HistoryItem[];
  bookmarks: Bookmark[];
  claimedDailyRewards: number[];
  messages: SystemMessage[];
}

export interface BrowserConfig {
  appName: string;
  packageName: string;
  firebaseProjectId: string;
  themeColor: string;
  homepageUrl: string;
  adSettings: AdSettings;
  system: {
    currentVersion: string;
    minRequiredVersion: string;
    forceUpdate: boolean;
    updateUrl: string;
    maintenanceMode: boolean;
  };
  analytics: {
    dau: number;
    impressions: number;
    clicks: number;
    ctr: number;
    revenue: number;
    history: number[];
    totalRewardsPaid: number;
  };
  branding: {
    appIcon: string;
    fontFamily: string;
    searchEngine: string;
    roundedness: 'sm' | 'md' | 'lg' | 'full';
    glassIntensity: number;
  };
  preferences: {
    adBlockerActive: boolean;
    performanceModeActive: boolean;
    currency: CurrencyCode;
  };
  storeListing: any;
  legal: any;
  builds: any[];
  userStats: UserStats;
  isInitialized: boolean;
  customArticles: NewsItem[];
  memes: MemeItem[];
  internalAds: InternalAd[];
  supportTickets: SupportTicket[];
  referralConfig: {
    inviterReward: number;
    inviteeReward: number;
    enabled: boolean;
  };
}

export interface BrowserTab {
  id: string;
  url: string;
  title: string;
  history: string[];
  historyIndex: number;
  isDesktopMode: boolean;
  isIncognito: boolean;
  isLocked?: boolean;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  reward: number;
  goal: number;
  type: 'articles' | 'ads' | 'searches' | 'checkin' | 'time' | 'streak';
}

export type SearchEngine = 'google' | 'bing' | 'duckduckgo' | 'baidu';
export type FontFamily = 'sans' | 'serif' | 'mono';
export type CurrencyCode = 'USD' | 'INR';
