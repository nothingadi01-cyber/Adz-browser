
import React, { useState, useEffect } from 'react';
import BrowserView from './components/BrowserView';
import AdminDashboard from './components/AdminDashboard';
import SetupWizard from './components/SetupWizard';
import SplashScreenAd from './components/SplashScreenAd';
import UpdateOverlay from './components/UpdateOverlay';
import { BrowserConfig, Transaction } from './types/config';

const APP_VERSION = "4.0.0";

const DEFAULT_CONFIG: BrowserConfig = {
  appName: "AdSurf Pro",
  packageName: "com.adsurf.pro",
  firebaseProjectId: "adsurf-prod-882",
  themeColor: "indigo",
  homepageUrl: "adsurf://home",
  isInitialized: false,
  adSettings: {
    bannersEnabled: true,
    interstitialsEnabled: true,
    nativeAdsEnabled: true,
    splashEnabled: true,
    rewardedEnabled: true,
    exitAdsEnabled: true,
    appOpenEnabled: true,
    rewardedInterstitialEnabled: true,
    refreshInterval: 15,
    inactivityTimeout: 60,
    adSource: 'admob',
    adMobId: "ca-app-pub-3940256099942544~3347511713",
    bannerId: "ca-app-pub-3940256099942544/6300978111",
    interstitialId: "ca-app-pub-3940256099942544/1033173712",
    rewardedId: "ca-app-pub-3940256099942544/5224354917",
    nativeId: "ca-app-pub-3940256099942544/2247696110",
    nativeArticleId: "ca-app-pub-3940256099942544/2247696110",
    inFeedNativeId: "ca-app-pub-3940256099942544/2247696110",
    appOpenId: "ca-app-pub-3940256099942544/3419835294",
    rewardedInterstitialId: "ca-app-pub-3940256099942544/5354046379",
    homeTopId: "ca-app-pub-3940256099942544/2247696110",
    stickyBannerId: "ca-app-pub-3940256099942544/6300978111",
    exitAdProbability: 50
  },
  system: {
    currentVersion: APP_VERSION,
    minRequiredVersion: "3.5.0",
    forceUpdate: false,
    updateUrl: "https://play.google.com/store",
    maintenanceMode: false
  },
  analytics: {
    dau: 2450,
    impressions: 125000,
    clicks: 4200,
    ctr: 3.4,
    revenue: 1245.80,
    history: [45, 55, 65, 50, 80, 75, 95],
    totalRewardsPaid: 18400
  },
  branding: {
    appIcon: "🌐",
    fontFamily: "sans",
    searchEngine: "google",
    roundedness: 'lg',
    glassIntensity: 85
  },
  preferences: {
    adBlockerActive: false,
    performanceModeActive: false,
    currency: 'INR'
  },
  storeListing: {
    title: "AdSurf Pro: High Yield Browsing",
    shortDescription: "The only browser that pays you to stay informed.",
    fullDescription: "Join the browsing revolution.",
    keywords: "browser, ads, rewards",
    category: "Communication",
    contactEmail: "support@adsurf.io"
  },
  legal: {
    privacyPolicy: "We value your privacy...",
    termsConditions: "By using AdSurf..."
  },
  builds: [],
  userStats: {
    balance: 50.00,
    xp: 250,
    level: 1,
    adsWatched: 0,
    articlesRead: 0,
    searchesPerformed: 0,
    streak: 1,
    multiplier: 1.0,
    missionProgress: {},
    referralCode: "SURF-PRO",
    referralsJoined: 0,
    history: [],
    historyItems: [],
    bookmarks: [],
    claimedDailyRewards: [],
    messages: [
      { id: '1', title: 'Welcome to AdSurf Pro', body: 'Start browsing to earn real points today.', timestamp: Date.now(), type: 'info', isRead: false }
    ]
  },
  customArticles: [
    {
      id: 'ca_1',
      title: 'Global Tech Giants Announce AI Integration Protocol',
      source: 'TechPulse HQ',
      time: '2h ago',
      category: 'Tech',
      imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=800',
      content: 'A new standard for AI cross-communication has been announced by leading industry leaders, promising a more unified neural network grid.',
      isCustom: true
    },
    {
      id: 'ca_2',
      title: 'Crypto Yield Surges Amid New Browser Rewards Program',
      source: 'FinNode Daily',
      time: '4h ago',
      category: 'Finance',
      imageUrl: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&q=80&w=800',
      content: 'Investors are flocking to AdSurf Pro as the platform unveils its latest yield generation algorithms for web explorers.',
      isCustom: true
    },
    {
      id: 'ca_3',
      title: 'Future of Decentralized Web: The 2025 Roadmap',
      source: 'Cyber Editorial',
      time: '6h ago',
      category: 'Innovation',
      imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800',
      content: 'The blueprint for a truly decentralized internet is being finalized, with nodes across the globe preparing for a massive scale-up.',
      isCustom: true
    }
  ],
  memes: [
    { id: 'm1', title: 'Viral Distribution Active', imageUrl: 'https://images.unsplash.com/photo-1531259683007-016a7b628fc3?auto=format&fit=crop&q=80&w=400', likes: 124, timestamp: Date.now() },
    { id: 'm2', title: 'When the Ad Rewards Hit', imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=400', likes: 256, timestamp: Date.now() - 3600000 },
    { id: 'm3', title: 'Nodes Syncing Perfectly', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=400', likes: 89, timestamp: Date.now() - 7200000 },
    { id: 'm4', title: 'Infinite Browsing Loop', imageUrl: 'https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80&w=400', likes: 412, timestamp: Date.now() - 10800000 },
    { id: 'm5', title: 'The Grid Never Sleeps', imageUrl: 'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?auto=format&fit=crop&q=80&w=400', likes: 67, timestamp: Date.now() - 14400000 },
    { id: 'm6', title: 'Signal Loss... Just Kidding', imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&q=80&w=400', likes: 934, timestamp: Date.now() - 18000000 }
  ],
  internalAds: [
    { id: 'ad_1', title: 'Premium Upgrade', description: 'Double rewards instantly.', imageUrl: '', actionUrl: 'adsurf://premium', type: 'native', active: true }
  ],
  supportTickets: [
    { id: 't_1', user: 'SURF-PRO', subject: 'Reward Delay', message: 'Payout stuck in processing.', status: 'open', timestamp: Date.now() - 3600000 }
  ],
  referralConfig: {
    inviterReward: 25.00,
    inviteeReward: 10.00,
    enabled: true
  }
};

const App: React.FC = () => {
  const [config, setConfig] = useState<BrowserConfig>(DEFAULT_CONFIG);
  const [view, setView] = useState<'browser' | 'admin'>('browser');
  const [showSplash, setShowSplash] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('adsurf_v4_config_final');
    if (saved) {
      const parsed = JSON.parse(saved);
      setConfig(parsed);
      if (parsed.isInitialized && parsed.adSettings.splashEnabled) {
        setShowSplash(true);
      }
    }
  }, []);

  const updateConfig = (newConfig: BrowserConfig) => {
    setConfig(newConfig);
    localStorage.setItem('adsurf_v4_config_final', JSON.stringify(newConfig));
  };

  const handleCollectReward = (amount: number, label: string, type: Transaction['type'] = 'ad') => {
    const newTx: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      amount,
      label,
      timestamp: Date.now()
    };
    
    const nextStats = {
      ...config.userStats,
      balance: config.userStats.balance + amount,
      xp: config.userStats.xp + (amount * 10),
      history: [newTx, ...config.userStats.history].slice(0, 50)
    };

    updateConfig({ ...config, userStats: nextStats });
  };

  if (!config.isInitialized) {
    return <SetupWizard config={config} onComplete={updateConfig} />;
  }

  if (showSplash) {
    return <SplashScreenAd config={config} onFinish={() => setShowSplash(false)} />;
  }

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-50 ${config.branding.fontFamily === 'mono' ? 'font-mono' : 'font-sans'}`}>
      {/* ALWAYS ACCESSIBLE ADMIN TOGGLE */}
      <div className="fixed top-4 right-4 z-[1000] flex gap-2">
        <button 
          onClick={() => setView(view === 'browser' ? 'admin' : 'browser')}
          className="bg-slate-800/90 backdrop-blur-md border border-slate-700 px-4 py-2 rounded-full text-[9px] font-black hover:bg-indigo-600 transition-all shadow-2xl uppercase tracking-[0.2em] text-white"
        >
          {view === 'browser' ? '🔐 Command' : '🌐 Browser'}
        </button>
      </div>

      <main className="h-screen w-full relative overflow-hidden">
        {view === 'browser' ? (
          <>
            {config.system.maintenanceMode ? (
              <div className="h-full bg-slate-950 flex flex-col items-center justify-center p-12 text-center space-y-6">
                <div className="text-7xl animate-pulse">🛠️</div>
                <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">Maintenance_Active</h2>
                <p className="text-slate-500 text-sm max-w-xs mx-auto">Nodes are currently offline for maintenance. Operational status will resume shortly.</p>
              </div>
            ) : (
              <BrowserView 
                config={config} 
                activeUrl={config.homepageUrl} 
                onNavigate={() => {}} 
                onUpdateConfig={updateConfig}
                onCollectReward={handleCollectReward}
              />
            )}
          </>
        ) : (
          <AdminDashboard 
            config={config} 
            onUpdate={updateConfig} 
          />
        )}
      </main>

      {config.system.forceUpdate && <UpdateOverlay config={config} />}
    </div>
  );
};

export default App;
